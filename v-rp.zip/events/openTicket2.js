//@ts-nocheck
// https://discord.js.org/#/docs/main/stable/class/Client?scrollTo=e-interactionCreate
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('@discordjs/builders');
const { Client, PermissionFlagsBits, ButtonStyle, Color } = require('discord.js');
const BaseEvent = require('../utils/structures/BaseEvent');
const s = require('../config');
const { ownersRole } = require('../config');
const { catgs2 } = require('../config');
const db = require("pro.db")

module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('interactionCreate');
  }
  /**
   * 
   * @param {Client} client 
   * @param {import('discord.js').Interaction} interaction 
   */
  async run(client, interaction) {
    if (!interaction.isButton()) return
    let sri = s.ownersRole //ايدي رتبة السبورت
    if (interaction.customId == "open2") {
        db.add("www3",1)
      let ch = await interaction.guild?.channels.create({
        name: `أونـر-${db.get("www3")}`,
        permissionOverwrites: [
          {
            id: interaction.guildId,
            deny: PermissionFlagsBits.ViewChannel
          },
          {
            id: interaction.member.id,
            allow: [PermissionFlagsBits.ViewChannel,PermissionFlagsBits.MentionEveryone,PermissionFlagsBits.AttachFiles]
          },
          {
            id: sri,
            allow: PermissionFlagsBits.ViewChannel
          }
        ],
        parent: catgs2
      })
      ch.send({
        content:`<@&${ownersRole}> - ${interaction.member}`,
        embeds: [new EmbedBuilder()
          .setColor(0xf1c40f)
          .setDescription(`**__<:A69:1257157369545228311> - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي طـلـب أونـر .

<:pp721:1257157453028786307> - نـرجـوا مـنـك عـزيـزي الـعـضـو إنـتـظـار أحـد أفـراد طـاقـم الأونـر لإسـتـلام تـذكـرتـك .__**`)],
        components: [new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId("claim2")
              .setStyle(ButtonStyle.Primary)
              .setLabel("أسـتـلام الـتـذكـرة"),
            new ButtonBuilder()
              .setCustomId("trk2")
              .setStyle(ButtonStyle.Success)
              .setLabel("تـرك الـتـذكـرة"),
            new ButtonBuilder()
              .setCustomId("delete2")
              .setStyle(ButtonStyle.Danger)
              .setLabel("حـذف الـتـذكـرة")
          )]
      })
      interaction.reply({ content: `**__<:pp721:1257157453028786307> - عـزيـزي الـعـضـو .

<a:emoji_194:1257157722911019039> - تـم فـتـح الـتـذكـرة بـنـجـاح .

<:T5:1257157539758346310> - الـتـذكـرة : ${ch} .__**`, ephemeral: true })
    }
  }
}