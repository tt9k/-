const { Client, PermissionFlagsBits, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const BaseEvent = require('../utils/structures/BaseEvent');
const s = require('../config');
const { catgs4 } = require('../config');
const db = require("pro.db");

module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('interactionCreate');
    this.answers = {};
    this.currentQuestion = 0;
    this.correctAnswers = 0;
    this.incorrectAnswers = 0;
  }

  /**
   * 
   * @param {Client} client 
   * @param {import('discord.js').Interaction} interaction 
   */
  async run(client, interaction) {
    if (!interaction.isButton() && !interaction.isModalSubmit()) return;

    let sri = s.supportId; // ايدي رتبة السبورت

    if (interaction.customId === "open") {
      db.add("www1", 1);
      let ch = await interaction.guild?.channels.create({
        name: `الـتـفـعـيـل-${db.get("www1")}`,
        permissionOverwrites: [
          {
            id: interaction.guildId,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: interaction.user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.MentionEveryone, PermissionFlagsBits.AttachFiles]
          },
          {
            id: sri,
            allow: [PermissionFlagsBits.ViewChannel]
          }
        ],
        parent: catgs4
      });

      const startSurveyButton = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("start_survey")
          .setStyle(ButtonStyle.Primary)
          .setLabel("ابدأ الاستبيان")
      );

      await ch.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xf1c40f)
            .setDescription("**__إسـتـبـيـان تـفـعـيـل فـي دولـة وولـف كـيـنـق. اضغط على الزر أدناه لبدء الاستبيان.__**")
        ],
        components: [startSurveyButton]
      });

      await ch.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xf1c40f)
            .setDescription("**__<:A69:1257157369545228311> - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي قـسـم الـتـفـعـيـل .\n\n<:pp721:1257157453028786307> - نـرجـوا مـنـك عـزيـزي الـعـضـو إنـتـظـار أحـد أفـراد طـاقـم الإدارة لإسـتـلام تـذكـرتـك .__**")
        ],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("claim")
            .setStyle(ButtonStyle.Primary)
            .setLabel("أسـتـلام الـتـذكـرة"),
          new ButtonBuilder()
            .setCustomId("trk")
            .setStyle(ButtonStyle.Success)
            .setLabel("تـرك الـتـذكـرة"),
          new ButtonBuilder()
            .setCustomId("delete")
            .setStyle(ButtonStyle.Danger)
            .setLabel("حـذف الـتـذكـرة")
        )]
      });

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xf1c40f)
            .setDescription(`**__<:pp721:1257157453028786307> - عـزيـزي الـعـضـو .\n<a:emoji_194:1257157722911019039> - تـم فـتـح الـتـذكـرة بـنـجـاح .\n<:T5:1257157539758346310> - الـتـذكـرة : ${ch} .__**`)
        ],
        ephemeral: true
      });
    }

    if (interaction.customId === "start_survey") {
      const questions = [
        { question: "أسـمـك:", type: "text" },
        { question: "عـمرك:", type: "text" },
        { question: "أيـديك:", type: "text" },
        { question: "مـاهو الـقانون الذهبي:", options: ["قانون1", "قانون2", "قانون3"], correct: "قانون1" },
        // أضف الأسئلة الأخرى بنفس النمط
      ];

      this.currentQuestion = 0;
      this.answers = {};
      this.correctAnswers = 0;
      this.incorrectAnswers = 0;

      const askQuestion = async (interaction) => {
        if (this.currentQuestion < 3) {
          const { question } = questions[this.currentQuestion];

          const modal = new ModalBuilder()
            .setCustomId(`modal_${this.currentQuestion}`)
            .setTitle("الاستبيان")
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId(`answer_${this.currentQuestion}`)
                  .setLabel(question)
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              )
            );

          await interaction.showModal(modal);
        } else if (this.currentQuestion < questions.length) {
          const { question, options } = questions[this.currentQuestion];

          const questionEmbed = new EmbedBuilder()
            .setColor(0x2f3136)
            .setDescription(question);

          const optionButtons = options.map(option => 
            new ButtonBuilder()
              .setCustomId(`option_${this.currentQuestion}_${option}`)
              .setLabel(option)
              .setStyle(ButtonStyle.Secondary)
          );

          await interaction.update({
            embeds: [questionEmbed],
            components: [new ActionRowBuilder().addComponents(optionButtons)]
          });
        } else {
          await interaction.channel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(0xf1c40f)
                .setDescription(`**__تم اكتمال الاستبيان! شكراً لإجاباتك. هذه هي إجاباتك:\n${Object.entries(this.answers).map(([key, value]) => `${key}: ${value}`).join("\n")}\nعدد الإجابات الصحيحة: ${this.correctAnswers}\nعدد الإجابات الخاطئة: ${this.incorrectAnswers}__**`)
            ]
          });
        }
      };

      const filter = i => i.customId.startsWith('option_') && i.user.id === interaction.user.id;

      const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async i => {
        const [_, questionIndex, selectedOption] = i.customId.split('_');
        const question = questions[parseInt(questionIndex)];
        if (selectedOption === question.correct) {
          this.correctAnswers++;
          this.answers[question.question] = `${selectedOption} (صحيح)`;
        } else {
          this.incorrectAnswers++;
          this.answers[question.question] = `${selectedOption} (خاطئ)`;
        }
        this.currentQuestion++;
        await askQuestion(i);
      });

      collector.on('end', async collected => {
        if (this.currentQuestion < questions.length) {
          await interaction.channel.send({
            embeds: [
              new EmbedBuilder()
                .setColor(0xf1c40f)
                .setDescription("**__تم انتهاء الوقت لإكمال الاستبيان. حاول مرة أخرى بالضغط على الزر.__**")
            ],
            components: [new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("start_survey")
                .setStyle(ButtonStyle.Primary)
                .setLabel("ابدأ الاستبيان")
            )]
          });
        }
      });

      await askQuestion(interaction);
    }

    if (interaction.isModalSubmit()) {
      const currentQuestion = parseInt(interaction.customId.split('_')[1]);
      const answer = interaction.fields.getTextInputValue(`answer_${currentQuestion}`);
      this.answers[questions[currentQuestion].question] = answer;
      this.currentQuestion++;
      await interaction.reply({ content: "تم تسجيل إجابتك.", ephemeral: true });
      await this.askQuestion(interaction);
    }
  }
};
