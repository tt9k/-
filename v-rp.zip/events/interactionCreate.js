const { InteractionType, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonStyle } = require('discord.js');
const bank = require('../models/bank');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (interaction.isButton()) {
      if (interaction.customId === 'check_balance') {
        const data = await bank.findOne({ user: interaction.user.id });

        if (!data) {
          return interaction.reply({
            embeds: [
              new EmbedBuilder()
                .setDescription('**لا يـوجـد لـديـك حـسـاب مـصـرفـي يـرجـى الـتـوجـة الـى الـدعـم الـفـنـي لـفـتـح حـسـاب مـصـرفـي**')
                .setColor("DarkRed")
                .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            ],
            ephemeral: true
          });
        }

        const embed = new EmbedBuilder()
          .setColor("Gold")
          .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
          .setTimestamp()
          .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
          .setDescription(`**__<:emoji_130:1257168936605061202> – أهـلآ بـك فـي مـصـرف الـراجـحـي .

<:pp721:1257157453028786307> - عـزيـزي المـواطـن رصـيـدك الـحـالـي .

<:emoji_171:1257173941936459867>  - الــكــاش : ( ${data.amount} ) .

<:emoji_172:1257173963134472254> - الـبـنـك : ( ${data.bank} ) .

<:T5:1257157539758346310>  - إجـمـالـي الـرصـيـد : ( ${data.amount + data.bank} ) .

<:emoji_130:1257393104315482192> - وزارة المـالـيـة .__**`)
          .setFooter({
            text: interaction.guild.name,
            iconURL: interaction.guild.iconURL()
          });

        await interaction.reply({ embeds: [embed], ephemeral: true });
      } else if (interaction.customId === 'transfer_money') {
        const modal = new ModalBuilder()
          .setCustomId('transfer_modal')
          .setTitle('تحويل مبلغ');

        const recipientInput = new TextInputBuilder()
          .setCustomId('recipient_id')
          .setLabel('معرف الشخص')
          .setStyle(TextInputStyle.Short);

        const amountInput = new TextInputBuilder()
          .setCustomId('amount')
          .setLabel('المبلغ')
          .setStyle(TextInputStyle.Short);

        const firstActionRow = new ActionRowBuilder().addComponents(recipientInput);
        const secondActionRow = new ActionRowBuilder().addComponents(amountInput);

        modal.addComponents(firstActionRow, secondActionRow);

        await interaction.showModal(modal);
      }
    } else if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'transfer_modal') {
      const recipientId = interaction.fields.getTextInputValue('recipient_id');
      const amount = parseInt(interaction.fields.getTextInputValue('amount'));

      if (!recipientId || isNaN(amount) || amount <= 0) {
        return interaction.reply({ content: 'يرجى التأكد من صحة المعلومات المدخلة.', ephemeral: true });
      }

      let sender = await bank.findOne({ user: interaction.user.id });
      let receiver = await bank.findOne({ user: recipientId });

      if (!receiver) {
        return interaction.reply({ content: 'المستلم غير موجود.', ephemeral: true });
      }

      if (sender.amount < amount) {
        return interaction.reply({ content: 'رصيدك غير كافٍ لإجراء التحويل.', ephemeral: true });
      }

      sender.amount -= amount;
      receiver.amount += amount;

      await sender.save();
      await receiver.save();

      const successEmbed = new EmbedBuilder()
        .setColor("Gold")
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setDescription(`**__<:emoji_130:1257168936605061202> - أهـلا بـك فـي مـصـرف الـراجـحـي .

<a:emoji_194:1257157722911019039> - تـم تـحـويـل الـمـبـلـغ بـنـجـاح .

<:pp721:1257157453028786307> - الـمـواطـن الـذي تـم تـحـويـلـة : <@${recipientId}> .

<:emoji_172:1257173963134472254> - الـمـبـلـغ الـذي تـم تـحـويـلـة : ( ${amount} ) .__**`)
        .setFooter({
          text: interaction.guild.name,
          iconURL: interaction.guild.iconURL()
        });

      await interaction.reply({ embeds: [successEmbed], ephemeral: true });

      try {
        const user = await interaction.client.users.fetch(recipientId);
        await user.send({
          embeds: [
            new EmbedBuilder()
              .setColor("Gold")
              .setDescription(`**__<:emoji_130:1257168936605061202> - أهـلا بـك فـي مـصـرف الـراجـحـي .

<:pp721:1257157453028786307> -  حـوالـة واردة مـن : ${interaction.user} .

<:emoji_172:1257173963134472254> - مـبـلـغ الـحـوالـة : ( ${amount} ) .__**`)
              .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL()
              })
          ]
        });
      } catch (error) {
        console.error('فشل إرسال رسالة للمستلم:', error);
      }
    }
  }
};
