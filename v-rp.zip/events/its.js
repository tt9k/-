// https://discord.js.org/#/docs/main/stable/class/Client?scrollTo=e-interactionCreate
const { Client, ModalSubmitInteraction , EmbedBuilder} = require('discord.js');
const profile = require('../models/profile');
const BaseEvent = require('../utils/structures/BaseEvent');
module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('interactionCreate');
  }
  /**
   * 
   * @param {Client} client 
   * @param {ModalSubmitInteraction} interaction 
   */
  async run(client, interaction) {
    if(!interaction.isModalSubmit()) return
     let data = await profile.findOne({user: interaction.customId})
     if(!data){
      interaction.reply({content: ":x:",ephemeral : true})
      return
     }
     data.Sawabek = interaction.fields.getTextInputValue("s")
     data.jailTimes = interaction.fields.getTextInputValue("n")
     data.job = interaction.fields.getTextInputValue("j")
     data.HalaJenea = interaction.fields.getTextInputValue("h")
     await data.save()
     interaction.update({components:[],embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـعـسـكـري .

<a:emoji_194:1257157722911019039> - تـم إنـشـاء الـسـجـل الـمـدنـي للـمـواطـن بـنـجـاح .

( وشـكـرآ لـك )__**`).setColor("Gold").setAuthor({name: interaction.user.username,iconURL: interaction.user.displayAvatarURL({dynamic:true})})]})
  }
}
  