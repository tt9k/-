// @ts-nocheck
// https://discord.js.org/#/docs/main/stable/class/Client?scrollTo=e-interactionCreate
const { Client, EmbedBuilder } = require('discord.js');
const { ownersRole } = require('../config');
const BaseEvent = require('../utils/structures/BaseEvent');
const points = require('../models/points');
module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('interactionCreate');
  }
  /**
   * 
   * @param {Client} client 
   * @param {import('discord.js').Interaction} interaction 
   */
  async run(client, interaction) {
    if (!interaction.isButton()) return
    if (interaction.customId == "claim2") {
      if (!interaction.member.roles.cache.has(ownersRole)) return
        if(await client.n38th.get(interaction.channelId)) return interaction.reply({content : "التكت مستلمة بالفعل",ephemeral : true})
      client.n38th.set(interaction.channelId,interaction.user.id)
      async function addPoints(id){
        let data = await points.findOne({user : id})
        if(!data) data = new points({user : id})
        data.ticket +=1;
        await data.save()
      }
      await addPoints(interaction.user.id)
      interaction.channel.permissionOverwrites.edit(interaction.user.id, {
        ViewChannel: true
      })

      interaction.channel.permissionOverwrites.edit(ownersRole, {
        ViewChannel: false
      })
      interaction.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor("Gold")
            .setDescription(`**__<:pp721:1257157453028786307> - مـرحـبـآ بـك عـزيـزي الـعـضـو .

<a:emoji_194:1257157722911019039> - تـم إسـتـلام تـذكـرتـك مـن أحـد أفـراد طـاقـم الإدارة : ${interaction.member} .

( وشـكـرآ لـك لإنـتـظـارك )__**`)

        ]
      })
      client.channels.cache.get("1257583016881164318").send({
        embeds : [
          new EmbedBuilder()
          .setColor("Random")
          .setTimestamp()
          .setFooter({iconURL : client.user?.displayAvatarURL(),text : client.user?.username})
          .setDescription(`
  تم اضافه نقاط
  
  الإداري : ${interaction.member}
          
  السبب : استلام تكت
  `)
        ]
      })
    }
    if (interaction.customId == "trk2") {
      if (!interaction.member.roles.cache.has(ownersRole)) return
        if(!await client.n38th.get(interaction.channelId)) return interaction.reply({content : "التكت غير مستلمة",ephemeral : true})
      if(await client.n38th.get(interaction.channelId) != interaction.user.id) return interaction.reply({content : "لست مالك التكت",ephemeral : true})
            await client.n38th.delete(interaction.channelId)
      async function addPoints(id){
        let data = await points.findOne({user : id})
        if(!data) data = new points({user : id})
        data.ticket -=1;
        await data.save()
      }
      await addPoints(interaction.user.id)
      interaction.channel.permissionOverwrites.edit(ownersRole, {
        ViewChannel: true
      })
                    interaction.channel.permissionOverwrites.edit(interaction.member.id, {
        ViewChannel: null
      })
       interaction.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor("Gold")
            .setDescription(`**__<:pp721:1257157453028786307> - مـرحـبـآ بـك عـزيـزي الـعـضـو .

<a:emoji_194:1257157722911019039> - تـم تـرك تـذكـرتـك وسـوف يـتـم إسـتـلامـهـا مـن أحـد أفـراد طـاقـم الإدارة : ${interaction.member} .

( وشـكـرآ لـك )__**`)

        ]
      })
      client.channels.cache.get("1257583016881164318").send({
        embeds : [
          new EmbedBuilder()
          .setColor("Random")
          .setTimestamp()
          .setFooter({iconURL : client.user?.displayAvatarURL(),text : client.user?.username})
          .setDescription(`
  تم خصم نقاط
  
  الإداري : ${interaction.member}
          
  السبب : ترك تكت
  `)
        ]
      })
    }
    if (interaction.customId == "delete2") {
      if (!interaction.member.roles.cache.has(ownersRole)) return
      interaction.channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor("Gold")
            .setDescription(`**__<:pp721:1257157453028786307> - مـرحـبـآ بـك عـزيـزي الـعـضـو .

<a:emoji_194:1257157722911019039> - سـيـتـم  حـذف الـتـذكـرة خـلال خـمـس ثـوانـي: ${interaction.member} .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`)

        ]
      }) 
      setTimeout(() => {
        interaction.channel.delete();
      }, 5000);
    }
  }
}
