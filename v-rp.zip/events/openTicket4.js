//@ts-nocheck
// https://discord.js.org/#/docs/main/stable/class/Client?scrollTo=e-interactionCreate
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('@discordjs/builders');
const { Client, PermissionFlagsBits, ButtonStyle, Color } = require('discord.js');
const BaseEvent = require('../utils/structures/BaseEvent');
const s = require('../config');
const { catgs3 } = require('../config');
const db = require("pro.db")

module.exports = class InteractionCreateEvent extends BaseEvent {
  constructor() {
    super('interactionCreate');
  }
  /**
   * 
   * @param {Client} client 
   * @param {import('discord.js').Interaction} interaction 
   */
  async run(client, interaction) {
    if (!interaction.isButton()) return
    let sri = s.roel4 //ايدي رتبة السبورت
    if (interaction.customId == "open4") {
        db.add("www5",1)
      let ch = await interaction.guild?.channels.create({
        name: `الـشـكـاوي-${db.get("www5")}`,
        permissionOverwrites: [
          {
            id: interaction.guildId,
            deny: PermissionFlagsBits.ViewChannel
          },
          {
            id: interaction.member.id,
            allow: [PermissionFlagsBits.ViewChannel,PermissionFlagsBits.MentionEveryone,PermissionFlagsBits.AttachFiles]
          },
          {
            id: sri,
            allow: PermissionFlagsBits.ViewChannel
          }
        ],
        parent: catgs3
      })
      ch.send({
        content: `${interaction.member} - <@&${sri}>`,
        embeds: [new EmbedBuilder()
          .setColor(0xf1c40f)
          .setDescription(`**__<:A69:1257157369545228311> - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي الـشـكـاوي الـعـامـة .

<:pp721:1257157453028786307> - نـرجـوا مـنـك عـزيـزي الـعـضـو إنـتـظـار أحـد أفـراد طـاقـم الإدارة لإسـتـلام تـذكـرتـك .__**`)],
        components: [new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId("claim4")
              .setStyle(ButtonStyle.Primary)
              .setLabel("أسـتـلام الـتـذكـرة"),
            new ButtonBuilder()
              .setCustomId("trk4")
              .setStyle(ButtonStyle.Success)
              .setLabel("تـرك الـتـذكـرة"),
            new ButtonBuilder()
              .setCustomId("delete4")
              .setStyle(ButtonStyle.Danger)
              .setLabel("حـذف الـتـذكـرة")
          )]
      })
      interaction.reply({ content: `**__<:pp721:1257157453028786307> - عـزيـزي الـعـضـو .

<a:emoji_194:1257157722911019039> - تـم فـتـح الـتـذكـرة بـنـجـاح .

<:T5:1257157539758346310> - الـتـذكـرة : ${ch} .__**`, ephemeral: true })
    }
  }
}