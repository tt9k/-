const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { registerCommands, registerEvents } = require('./utils/registry');
const config = require('./slappey.json');
const client = new Client({ 
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.DirectMessages], 
  partials: [Partials.Message, Partials.Channel, Partials.User] 
});
const mongoose = require('mongoose');
const { QuickDB } = require("quick.db");

const db1 = new QuickDB();

(async () => {
  client.commands = new Map();
  client.events = new Map();
  client.prefix = config.prefix;
  client.n38th = db1;

  await registerCommands(client, '../commands');
  await mongoose.connect("mongodb+srv://16:uq0mX6098xCXj9Nk@cluster0.patfqqn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
  await registerEvents(client, '../events');

  client.setMaxListeners(20); 

  client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (command) {
        try {
          await command.execute(interaction, client);
        } catch (error) {
          console.error(error);
          await interaction.reply({ content: 'حدث خطأ ما أثناء تنفيذ الأمر.', ephemeral: true });
        }
      }
    }
  });

  require('./events/interactionCreate')(client);

})();

process.on('unhandledRejection', (reason, p) => {
  console.log(reason);
});

process.on('uncaughtException', (err, origin) => {
  console.log(err);
});

client.login(process.env.token);
