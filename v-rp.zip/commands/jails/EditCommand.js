const {
  Client,
  Message,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  Events
} = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Record = require('../../models/Record'); // استيراد نموذج البيانات

module.exports = class RegisterCommand extends BaseCommand {
  constructor() {
    super('سجل', 'sub', []);
  }

  async run(client, message, args) {
    const roleId = '1198059405296549918'; // معرف الرول المحدد

    if (!message.member.roles.cache.has(roleId)) {
      return message.reply({ content: "**<:ar_MEMBRS:1251487358998544464> － آخـي الـعـضـو لايـمـكـنـك أسـتـخـدام هـذا الامـر .**" }).then(msg => {
        setTimeout(() => msg.delete(), 5000);
      });
    }

    const embed = new EmbedBuilder()
      .setTitle("سجل مدني")
      .setDescription("**<:emoji_187:1253719953501061341> － اختر الإجراء الذي تود القيام به.**")
      .setColor(0x4B0082)
      .setImage("https://media.discordapp.net/attachments/1249608943806709850/1256261012034949162/20240618_215233.png?ex=66a1153d&is=669fc3bd&hm=cda3600067145a318c4a2848b54c245dd1151a34cc2be466c92aeafabde37379&=&format=webp&quality=lossless&width=1440&height=478")
      .setThumbnail("https://cdn.discordapp.com/icons/YOUR_SERVER_ID/YOUR_SERVER_ICON.png")
      .setFooter({ text: "سجل مدني" });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('register')
        .setLabel('انشاء سجل')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📝'),
      new ButtonBuilder()
        .setCustomId('edit')
        .setLabel('تعديل سجل')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('✏️'),
      new ButtonBuilder()
        .setCustomId('view')
        .setLabel('تبصيم')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('🔍')
    );

    let sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = async (message) => {
      const componentCollector = message.createMessageComponentCollector({ time: 3600000 });

      componentCollector.on('collect', async (interaction) => {
        if (interaction.customId === 'register') {
          const modal = new ModalBuilder()
            .setCustomId('registerModal')
            .setTitle('انشاء سجل')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('userid')
                  .setLabel('أدخل أيـدي الـعـضـو : ')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('s')
                  .setLabel('السوابق الجنائية : ')
                  .setStyle(TextInputStyle.Paragraph)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('n')
                  .setLabel('عدد مرات دخول السجن : ')
                  .setStyle(TextInputStyle.Paragraph)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('h')
                  .setLabel('الحالة الجنائية : ')
                  .setStyle(TextInputStyle.Paragraph)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('j')
                  .setLabel('الوظيفة : ')
                  .setStyle(TextInputStyle.Short)
              )
            );

          await interaction.showModal(modal);
        } else if (interaction.customId === 'edit') {
          const modal = new ModalBuilder()
            .setCustomId('editModal')
            .setTitle('تعديل سجل')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('userid')
                  .setLabel('أدخل أيـدي الـعـضـو : ')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('s')
                  .setLabel('السوابق الجنائية : ')
                  .setStyle(TextInputStyle.Paragraph)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('n')
                  .setLabel('عدد مرات دخول السجن : ')
                  .setStyle(TextInputStyle.Paragraph)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('h')
                  .setLabel('الحالة الجنائية : ')
                  .setStyle(TextInputStyle.Paragraph)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('j')
                  .setLabel('الوظيفة : ')
                  .setStyle(TextInputStyle.Short)
              )
            );

          await interaction.showModal(modal);
        } else if (interaction.customId === 'view') {
          const modal = new ModalBuilder()
            .setCustomId('viewUserIdModal')
            .setTitle('عرض سجل')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('viewUserId')
                  .setLabel('أدخل أيـدي الـعـضـو لعرض السجل : ')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              )
            );

          await interaction.showModal(modal);
        }
      });
    };

    collector(sentMessage);

    client.on(Events.MessageDelete, async (deletedMessage) => {
      if (deletedMessage.id === sentMessage.id) {
        const newSentMessage = await message.channel.send({ embeds: [embed], components: [row] });
        sentMessage = newSentMessage;
        await newSentMessage.react('✅');
        collector(newSentMessage);
      }
    });

    client.on(Events.InteractionCreate, async interaction => {
      if (interaction.isModalSubmit()) {
        const modalId = interaction.customId;
        await interaction.deferReply({ ephemeral: true });

        try {
          if (modalId === 'registerModal') {
            const userid = interaction.fields.getTextInputValue('userid');
            const sawabek = interaction.fields.getTextInputValue('s');
            const num = interaction.fields.getTextInputValue('n');
            const hala = interaction.fields.getTextInputValue('h');
            const job = interaction.fields.getTextInputValue('j');

            const newRecord = new Record({
              userId: userid,
              criminalRecords: sawabek,
              numInPrison: num,
              criminalStatus: hala,
              job: job
            });

            await newRecord.save();

            const embed = new EmbedBuilder()
              .setTitle('انشاء سجل')
              .setDescription(`**أيدي العضو:** ${userid}\n**السوابق الجنائية:** ${sawabek}\n**عدد مرات دخول السجن:** ${num}\n**الحالة الجنائية:** ${hala}\n**الوظيفة:** ${job}`)
              .setColor(0x4B0082);

            const targetChannel = client.channels.cache.get('1259927864879616264');
            await targetChannel.send({ embeds: [embed] });

            await interaction.editReply({ content: 'تم تسجيل بياناتك بنجاح.', ephemeral: true });

          } else if (modalId === 'editModal') {
            const userid = interaction.fields.getTextInputValue('userid');
            const record = await Record.findOne({ userId: userid });

            if (record) {
              const modal = new ModalBuilder()
                .setCustomId('editRecordModal')
                .setTitle('تعديل سجل')
                .addComponents(
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('s')
                      .setLabel('السوابق الجنائية : ')
                      .setStyle(TextInputStyle.Paragraph)
                      .setValue(record.criminalRecords || '')
                  ),
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('n')
                      .setLabel('عدد مرات دخول السجن : ')
                      .setStyle(TextInputStyle.Paragraph)
                      .setValue(record.numInPrison || '')
                  ),
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('h')
                      .setLabel('الحالة الجنائية : ')
                      .setStyle(TextInputStyle.Paragraph)
                      .setValue(record.criminalStatus || '')
                  ),
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('j')
                      .setLabel('الوظيفة : ')
                      .setStyle(TextInputStyle.Short)
                      .setValue(record.job || '')
                  )
                );

              await interaction.showModal(modal);

              client.once(Events.InteractionCreate, async secondInteraction => {
                if (secondInteraction.isModalSubmit() && secondInteraction.customId === 'editRecordModal') {
                  const sawabek = secondInteraction.fields.getTextInputValue('s');
                  const num = secondInteraction.fields.getTextInputValue('n');
                  const hala = secondInteraction.fields.getTextInputValue('h');
                  const job = secondInteraction.fields.getTextInputValue('j');

                  await Record.updateOne({ userId: userid }, {
                    criminalRecords: sawabek,
                    numInPrison: num,
                    criminalStatus: hala,
                    job: job
                  });

                  await secondInteraction.editReply({ content: 'تم تعديل السجل بنجاح.', ephemeral: true });
                }
              });
            } else {
              await interaction.editReply({ content: 'لم يتم العثور على سجل بهذا الأيدي.', ephemeral: true });
            }
          } else if (modalId === 'viewUserIdModal') {
            const viewUserId = interaction.fields.getTextInputValue('viewUserId');
            const record = await Record.findOne({ userId: viewUserId });

            if (record) {
              const embed = new EmbedBuilder()
                .setTitle('السجل')
                .setDescription(`**أيدي العضو:** ${record.userId}\n**السوابق الجنائية:** ${record.criminalRecords}\n**عدد مرات دخول السجن:** ${record.numInPrison}\n**الحالة الجنائية:** ${record.criminalStatus}\n**الوظيفة:** ${record.job}`)
                .setColor(0x4B0082);

              await interaction.editReply({ embeds: [embed], ephemeral: true });
            } else {
              await interaction.editReply({ content: 'سجل العضو غير موجود.', ephemeral: true });
            }
          }
        } catch (error) {
          console.error('Error:', error);
          await interaction.editReply({ content: 'حدث خطأ أثناء إرسال المعلومات.', ephemeral: true });
        }
      }
    });
  }
};
