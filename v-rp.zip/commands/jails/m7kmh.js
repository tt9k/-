const { Client, Message, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');

module.exports = class CourtCommand extends BaseCommand {
  constructor() {
    super('محكمة', 'sub', []);
  }

  async run(client, message, args) {
    const roleId = '1198059405296549918'; // معرف الرول المحدد

    if (!message.member.roles.cache.has(roleId)) {
      return message.reply({ content: "**<:ar_MEMBRS:1251487358998544464> － آخـي الـعـضـو لايـمـكـنـك أسـتـخـدام هـذا الامـر .**" }).then(msg => {
        setTimeout(() => msg.delete(), 5000);
      });
    }

    const embed = new EmbedBuilder()
      .setTitle("محكمة")
      .setDescription(``)
      .setColor(0x4B0082)
      .setThumbnail("https://cdn.discordapp.com/icons/YOUR_SERVER_ID/YOUR_SERVER_ICON.png")
      .setFooter({ text: "محكمة" });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('raise_case')
        .setLabel('رفع قضية')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('📝'),
      new ButtonBuilder()
        .setCustomId('request_lawyer')
        .setLabel('طلب محامي')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('⚖️')
    );

    let sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = async (message) => {
      const componentCollector = message.createMessageComponentCollector({ time: 3600000 });

      componentCollector.on('collect', async (interaction) => {
        if (interaction.customId === 'raise_case') {
          const modal = new ModalBuilder()
            .setCustomId('raiseCaseModal')
            .setTitle('رفع قضية')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('fullName')
                  .setLabel('الاسم الثلاثي')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('defendantId')
                  .setLabel('أيدي المدعي عليه')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('caseReason')
                  .setLabel('سبب رفع القضية')
                  .setStyle(TextInputStyle.Paragraph)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('evidence')
                  .setLabel('هل تمتلك الأدلة الكافية')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('caseType')
                  .setLabel('نوع القضية')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              )
            );

          await interaction.showModal(modal);
        } else if (interaction.customId === 'request_lawyer') {
          const modal = new ModalBuilder()
            .setCustomId('requestLawyerModal')
            .setTitle('طلب محامي')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('fullName')
                  .setLabel('الاسم الثلاثي')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('caseType')
                  .setLabel('نوع القضية')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('caseNumber')
                  .setLabel('رقم القضية')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('role')
                  .setLabel('هل أنت المتهم أم الداعي')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              )
            );

          await interaction.showModal(modal);
        }
      });
    };

    collector(sentMessage);

    client.on(Events.MessageDelete, async (deletedMessage) => {
      if (deletedMessage.id === sentMessage.id) {
        const newSentMessage = await message.channel.send({ embeds: [embed], components: [row] });
        sentMessage = newSentMessage;
        await newSentMessage.react('✅');
        collector(newSentMessage);
      }
    });

    client.on(Events.InteractionCreate, async interaction => {
      if (interaction.isModalSubmit()) {
        const modalId = interaction.customId;
        console.log(`Modal ID: ${modalId}`); // Log the modal ID
        await interaction.deferReply({ ephemeral: true });

        try {
          if (modalId === 'raiseCaseModal') {
            const fullName = interaction.fields.getTextInputValue('fullName');
            const defendantId = interaction.fields.getTextInputValue('defendantId');
            const caseReason = interaction.fields.getTextInputValue('caseReason');
            const evidence = interaction.fields.getTextInputValue('evidence');
            const caseType = interaction.fields.getTextInputValue('caseType');

            const embed = new EmbedBuilder()
              .setTitle('رفع قضية')
              .setDescription(`**الاسم الثلاثي:** ${fullName}\n**أيدي المدعي عليه:** ${defendantId}\n**سبب رفع القضية:** ${caseReason}\n**هل تمتلك الأدلة الكافية:** ${evidence}\n**نوع القضية:** ${caseType}`)
              .setColor(0x4B0082);

            const targetChannel = client.channels.cache.get('1259927864879616264');
            const sentCaseMessage = await targetChannel.send({ embeds: [embed], components: [
              new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                  .setCustomId('receive_case')
                  .setLabel('استلام القضية')
                  .setStyle(ButtonStyle.Primary)
                  .setEmoji('📩')
              )
            ]});

            const caseCollector = sentCaseMessage.createMessageComponentCollector({ time: 3600000 });

            caseCollector.on('collect', async (interaction) => {
              if (interaction.customId === 'receive_case') {
                const caseNumber = Math.floor(100000 + Math.random() * 900000);
                const initiator = message.author;

                // إرسال المعلومات بشكل خاص
                await initiator.send(`تم استلام قضيتك من قبل ${interaction.user.tag}. نرجو أن تكونوا متواجدين لأي استدعاء.`);
                await client.users.cache.get(defendantId).send(`تم رفع قضية ضدك بواسطة ${initiator.tag}. سبب القضية: ${caseReason}. مستلم القضية: ${interaction.user.tag}`);

                await interaction.reply({ content: 'تم استلام القضية بنجاح.', ephemeral: true });
              }
            });

            await interaction.editReply({ content: 'تم رفع القضية بنجاح.', ephemeral: true });
          } else if (modalId === 'requestLawyerModal') {
            const fullName = interaction.fields.getTextInputValue('fullName');
            const caseType = interaction.fields.getTextInputValue('caseType');
            const caseNumber = interaction.fields.getTextInputValue('caseNumber');
            const role = interaction.fields.getTextInputValue('role');

            const embed = new EmbedBuilder()
              .setTitle('طلب محامي')
              .setDescription(`**الاسم الثلاثي:** ${fullName}\n**نوع القضية:** ${caseType}\n**رقم القضية:** ${caseNumber}\n**الدور:** ${role}`)
              .setColor(0x4B0082);

            const targetChannel = client.channels.cache.get('1261375954068963389');
            const sentLawyerRequest = await targetChannel.send({ embeds: [embed], components: [
              new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                  .setCustomId('receive_lawyer_request')
                  .setLabel('استلام الطلب')
                  .setStyle(ButtonStyle.Primary)
                  .setEmoji('📩')
              )
            ]});

            const lawyerCollector = sentLawyerRequest.createMessageComponentCollector({ time: 3600000 });

            lawyerCollector.on('collect', async (interaction) => {
              if (interaction.customId === 'receive_lawyer_request') {
                const requestNumber = Math.floor(100000 + Math.random() * 900000);
                const initiator = message.author;

                // إرسال المعلومات بشكل خاص
                await initiator.send(`تم استلام طلبك من قبل ${interaction.user.tag}. نرجو أن تكونوا متواجدين لأي استدعاء.`);
                await interaction.reply({ content: 'تم استلام الطلب بنجاح.', ephemeral: true });
              }
            });

            await interaction.editReply({ content: 'تم طلب المحامي بنجاح.', ephemeral: true });
          }
        } catch (error) {
          console.error('Error handling modal submission:', error);
        }
      }
    });
  }
};
