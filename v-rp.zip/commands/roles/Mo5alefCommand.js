// @ts-nocheck
const { Client, Message, EmbedBuilder } = require('discord.js');
const { blackListAdmin, blackListRoleId, blackListlogChannel } = require('../../config');
const BaseCommand = require('../../utils/structures/BaseCommand');
const jail = require("../../models/jail")
module.exports = class Mo5alefCommand extends BaseCommand {
  constructor() {
    super('سجن', 'roles', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(blackListAdmin)) return
    if (!message.mentions.members.first()) return message.channel.send(`**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو الـذي تـرغـب فـي سـجـنـة .

( وشـكـرآ لـك )__**`)
    if (!args[1]) return message.channel.send(`**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن سـبـب سـجـن الـعـضـو الـذي تـرغـب فـي سـجـن .

( وشـكـرآ لـك )__**`)
    let member = message.mentions.members.first()
    member.setNickname(args[1])
    member.roles.cache.forEach(async x => {
      if(x.id == member.guild.id) return
      await member.roles.remove(x.id)
    })
    await member.roles.add(blackListRoleId)
    client.channels.cache.find(x => x.id == blackListlogChannel).send({
      embeds: [
        new EmbedBuilder()
          .setColor("Red")
          .setTimestamp()
          .setFooter({
            text: member.guild.name,
            iconURL: member.guild.iconURL()
          })
          .setDescription(`
لقد قام الادمن : ${message.member}
بسجن العضو : ${member}
بسبب : ${args[1]}
في تاريخ : <t:${Math.floor(Date.now() / 1000)}:R>`)
      ]
    })
    ////
    await jail.findOneAndDelete({ user: member.id })
    let data = new jail({
      user: member.id,
      reason : args[1]
    })
    await data.save()
    message.channel.send({
      content: `**__<:A69:1257157369545228311> - عـزيـزي الإداري .

<a:emoji_194:1257157722911019039> - تـم سـجـن الـعـضـو بـنـجـاح .

<:pp721:1257157453028786307> - الـعـضـو : ${member} .

( وشـكـرآ لـك )__**`
    })
  }
}