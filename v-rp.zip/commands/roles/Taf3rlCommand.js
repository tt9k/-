const { Client, GatewayIntentBits, Partials, EmbedBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank");
const s = require("../../config");
const { logChannel: logChannelId, pointsLogChannelID } = require('../../config');
const points = require('../../models/points');
const identity1 = require("../../models/identity1");

module.exports = class Taf3rlCommand extends BaseCommand {
  constructor() {
    super('تفعيل', 'roles', []);
  }

  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   */
  async run(client, message) {
    if (!message.member.roles.cache.has(s.role) && message.author.id !== "1265144461600755753") 
      return message.reply({ content: "لاتمتلك صلاحية استخدام هذا الامر", ephemeral: true });
    if (message.channel.id !== "1265144461600755753" && message.author.id !== "1265144461600755753") 
      return message.reply({ content: `لاستخدام الامر الرجاء الذهاب الى : <#1265144461600755753>`, ephemeral: true });

    let deleteRoles = s.deleteRoles;
    let addRoles = s.addRoles;

    if (!message.mentions.members.first()) 
      return message.reply({ content: "منشن عضو", ephemeral: true });

    const mem = message.mentions.members.first();
    let ID = message.content.split(' ')[2] || mem.id; 

    let latestIdentity = await identity1.findOne().sort({ identity: -1 });
    let newIdentity = (latestIdentity ? latestIdentity.identity : 1999) + 1;

    const identityData = new identity1({
      serverId: message.guild.id,
      userId: mem.id,
      identity: newIdentity
    });
    await identityData.save();

    await mem.setNickname(`#${newIdentity} ${ID}`);

    for (let x of deleteRoles) {
      await mem.roles.remove(x);
    }

    for (let x of addRoles) {
      await mem.roles.add(x);
    }

    try {
      const logChannel = client.channels.cache.get(logChannelId);
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor("Green")
          .setTimestamp()
          .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
          .setTitle("تفعيل عضو")
          .setDescription(`
            تم تفعيل العضو : ${mem}
            في الساعة : <t:${Math.floor(Date.now() / 1000)}:R>
            بواسطة الاداري : ${message.member}
            الهوية : #${newIdentity}
            الايدي : ${mem.id}
          `);

        logChannel.send({ embeds: [embed] });
      }

      message.reply({ content: `تم تفعيل \`العضو\` بنجاح ✅`, ephemeral: true });

      const embedMsg = new EmbedBuilder()
        .setColor("White")
        .setTitle("**__ \<:1k_rajhi:1248609123189129328>| بنك الراجحي  __**")
        .setDescription(`** || عزيزي المواطن : ${mem} **\n\n**__تم تفعيل حسابك البنكي بنجاح __ **\n\n**وزارة المالية**`)
        .setFooter({ text: ` بنك الراجحي `, iconURL: client.user.avatarURL() });

      message.channel.send({ embeds: [embedMsg] });

      let check = await bank.findOne({ user: mem.id });
      if (!check) {
        let data = new bank({
          user: mem.id,
          amount: 5000,
          createdAt: Date.now()
        });
        await data.save();
      }

      mem.send({
        content: `
          <:1k_rajhi:1248609123189129328>
          **|| عزيزي المواطن : ${mem} **

         <:1k_rajhi:1248609123189129328>
          **__تم إيداع ( 5000 ) لحسابك البنكي __**

          <:oLd:1248609397425442888> **|| وزارة الـمـالـيـة **
        `
      }).catch(console.error);

      async function addPoints(id) {
        let data = await points.findOne({ user: id });
        if (!data) data = new points({ user: id });
        data.tafeel += 1;
        await data.save();
      }

      await addPoints(message.member.id);

      const pointsLogChannel = client.channels.cache.get(pointsLogChannelID);
      if (pointsLogChannel) {
        pointsLogChannel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("Random")
              .setTimestamp()
              .setFooter({ text: client.user?.username, iconURL: client.user?.displayAvatarURL() })
              .setDescription(`
                تم اضافه نقاط

                الإداري : ${message.member}

                السبب : تفعيل عضو
              `)
          ]
        });
      }
    } catch (error) {
      console.error(error);
      message.reply('حدث خطأ أثناء معالجة الطلب.');
    }
  }
}
