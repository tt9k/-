const { ActionRowBuilder, StringSelectMenuBuilder , EmbedBuilder} = require('@discordjs/builders');
const { Client, Message, SelectMenuOptionBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
let rolesDb = [
  ["1257062415930097745","1253311852641915040","1244763714285076520","1244763705628164139"], // LSPD
  ["1257062415930097745","1253311898112360489","1244763714285076520","1244763705628164139"], // SWAT
  ["1253345357702631494","1253346857200123934"], // VAGOS
  ["1253345357702631494","1253342541462638622"], // TITANS
  ["1253345357702631494","1253342411330027542"], // BLOOD
  ["1253345357702631494","1257567847589089330"], // SCRAP
  ["1253338455220420670","1244763838700720211"], // قاضي
  ["1253338455220420670","1244763839388581908"], // محامي 
  ["1257918206379823176","1253426664826732585"] // اعلامي
]
module.exports = class AcceptCommand extends BaseCommand {
  constructor() {
    super('توظيف', 'roles', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member?.roles.cache.has("1257144280330408038")) return; 
    let ob = [
      {
        name : "- LSPD .",
        description:"- لـتـوظـيـف عـضـو وزارة الـداخـلـيـة قـطـاع LSPD .",
        id :"0"
      },
      {
        name : "- SWAT .",
        description:"- لـتـوظـيـف عـضـو وزارة الـداخـلـيـة قـطـاع SWAT .",
        id :"1"
      }
    ]
    let ob2 = [{
      name : "- Vagos .",
      description:"- لـتـوظـيـف عـضـو فـي الـعـالـم الإجـرامـي عـصـابـة Vagos .",
      id : "2"
    },{
      name : "- Titans .",
      description:"- لـتـوظـيـف عـضـو فـي الـعـالـم الإجـرامـي عـصـابـة Titans .",
      id : "3"
    },{
      name : "- Blood",
      description:"- لـتـوظـيـف عـضـو فـي الـعـالـم الإجـرامـي عـصـابـة Blood .",
      id : "4"
    },{
      name : "- Scrap .",
      description:"- لـتـوظـيـف عـضـو فـي الـعـالـم الإجـرامـي عـصـابـة Scrap .",
      id : "5"
    }]
    let ob3 = [{
      name : "- قـاضـي",
      description:"- لـتـوظـيـف عـضـو فـي وزارة الـعـدل تـخـصـص قـاضـي .",
      id: "6"
    },{
      name :"- محامي .",
      description:"- لـتـوظـيـف عـضـو فـي وزارة الـعـدل تـخـصـص مـحـامـي .",
      id : "7"
    },{
      name : "- إعـلامـي .",
      description:"- لـتـوظـيـف عـضـو فـي وزارة الإعـلام تـخـصـص إعـلامـي .",
      id : "8"
    }]
    if(!message.mentions.members?.first()) return message.reply({content : `**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو الـذي تـرغـب فـي تـوظـيـفـة .

( وشـكـرآ لـك )__**`})
    let s = new StringSelectMenuBuilder()
    .setCustomId("dp")
    .setMaxValues(1)
    .setPlaceholder("- الـقـطـاعـات الـحـكـومـيـة")
    ob.forEach(x=>{
      s.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id).setDescription(x.description)])
    })
    let s3 = new StringSelectMenuBuilder()
    .setCustomId("jp")
    .setMaxValues(1)
    .setPlaceholder("- الـوظـائـف الـحـكـومـيـة .")
    ob3.forEach(x=>{
      s3.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id).setDescription(x.description)])
    })
    let s2 =   new StringSelectMenuBuilder()
    .setCustomId("ot")
    .setMaxValues(1)
    .setPlaceholder("- الـعـالـم الإجـرامـي .")
    ob2.forEach(x=>{
      s2.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id).setDescription(x.description)])
    })
    let rowq = new ActionRowBuilder()
    .addComponents(
      s
    )
    let rowq2 = new ActionRowBuilder()
    .addComponents(
      s2
    )
    let rowq3 = new ActionRowBuilder()
    .addComponents(
      s3
    )
   let dk = await message.channel.send({embeds:[new EmbedBuilder().setDescription (`**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن أخـتـيـار الـوظـيـفـة الـذي تـرغـب فـي تـوظـيـفـة مـن أسـفـل الـرسـالـة .

( وشـكـرآ لـك )__**`).setColor(0xf1c40f)],components :[rowq,rowq2,rowq3]})
    const filter = (interaction) => interaction.user.id == message.author.id;

    let collected = await dk.awaitMessageComponent({ filter, time: 30_000}).catch((c) =>{
        message.delete()
    });
      if(!collected) return
    rolesDb[Number(collected.values[0])].forEach(k=>{
message.mentions.members.first()?.roles.add(k).catch(null)
    })
    dk.edit({embeds:[], components:[],content : `**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<a:emoji_194:1257157722911019039> - تـم تـوظـيـف الـعـضـو بـنـجـاح .

<:pp721:1257157453028786307> - الـعـضـو : ${message.mentions.members.first()} .

( وشـكـرآ لـك )__**`})
    let ob77 = ob.concat(ob2,ob3)
    
    client.channels.cache.get("1258087566805041162").send({
      content : `
تم توظيف العضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
الوظيفة : ${ob77.find(k=>k.id == collected.values[0])?.name}
`
    })
    }
}