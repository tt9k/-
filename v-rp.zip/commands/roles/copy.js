const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('@discordjs/builders');
const { Client, Message, SelectMenuOptionBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
let rolesDb = [
  ["1244763065690361888","1244763065690361888","1244762997755478117","1244758608529588376","1244762880646185154","1257092734909677670","1244763118848970795","1244763133659316244","1244763145264959621","1244763108233183334","1244763538459725877","1244763549017051137","1244763558408093847","1244763567316537406","1257092734909677670","1244763676049936565","1244763605753397318","1244763631670005781","1244763640893145099","1244763538459725877","1244763695675080777","1244763655179075614","1244763705628164139","1244763676049936565","1244763666067357736","1257062415930097745","1253311852641915040","1244763714285076520","1244763685994631188","1253311898112360489"],
  ["1244763839388581908","1244763829607465030","1253313016137519135","1244763838700720211","1253338455220420670"],
  ["1253338725132537916","1253338657629147136","1257918206379823176","1257918479374483516","1257918656227311737","1253426664826732585"],
  ["1257566102406299648","1257566040347508808","1253342620328132700","1253342742881374318","1253342885189783612","1257566635057872978","1257566547262574663","1257566479285616641","1253346857200123934","1257566187920031795","1253342411330027542","1257567152479666176","1257567050977509450","1257566926897545287","1253342541462638622","1253346011259342939","1257567847589089330","1257567472211722294","1257567388665122869","1257567307794878548","1253345357702631494","1253345467924742255","1253345544802275431","1253345623223042129"]

]
module.exports = class AcceptCommand extends BaseCommand {
  constructor() {
    super('تقاعد', 'roles', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member?.roles.cache.has("1257144280330408038")) return;
    let ob = [
      {
        name : "- وزارة الـداخـلـيـة .",
        description:"- للـتـقـاعـد مـن وزارة الـداخـلـيـة .",
        id :"0"
      }, {
        name : "- وزارة الـعـدل .",
        description:"للـتـقـاعـد مـن وزارة الـعـدل",
        id :"1"
      }, {
        name : "- وزارة الإعـلام .",
        description:"- للـتـقـاعـد مـن وزارة الإعـلام .",
        id :"2"
      }, {
        name : "- الـعـصـابـات .",
        description:"- للـتـقـاعـد مـن الـعـصـابـات .",
        id :"3"
      }
    ]
    if(!message.mentions.members?.first()) return message.channel.send({content : `**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو الـذي تـرغـب فـي تـقـاعـدة .

( وشـكـرآ لـك )__**`})
    let s = new StringSelectMenuBuilder()
    .setCustomId("retirement")
    .setMaxValues(1)
    .setPlaceholder("- أخـتـر جـهـة الـتـقـاعـد .")
    ob.forEach(x=>{
      s.addOptions([new SelectMenuOptionBuilder().setLabel(x.name).setValue(x.id).setDescription(x.description)])
    })
    let rowq = new ActionRowBuilder()
    .addComponents(
      s
    )
   let dk = await  message.channel.send({embeds:[new EmbedBuilder().setDescription (`**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن أخـتـيـار الـوظـيـفـة الـذي تـرغـب فـي تـقـاعـدة مـن أسـفـل الـرسـالـة .

( وشـكـرآ لـك )__**`).setColor(0xf1c40f)],components :[rowq]})
    const filter = (interaction) => interaction.user.id == message.author.id;

    let collected = await dk.awaitMessageComponent({ filter, time: 30_000}).catch((c) =>{
        message.delete()
    });
    rolesDb[Number(collected.values[0])].forEach(k=>{
      message.mentions.members.first()?.roles.remove(k).catch(null)
    })
    dk.edit({embeds:[], components:[],content : `**__<:A69:1257157369545228311> – عـزيـزي الإداري .

<a:emoji_194:1257157722911019039> - تـم تـقـاعـد الـعـضـو بـنـجـاح .

<:pp721:1257157453028786307> - الـعـضـو : ${message.mentions.members.first()} .

( وشـكـرآ لـك )__**`})
    let ob77 = ob.concat(ob)
    
    client.channels.cache.get("1258087612971880508").send({
      content : `
تم تقاعد العضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
الوظيفة : ${ob77.find(k=>k.id == collected.values[0])?.name}
`})
    }
  }