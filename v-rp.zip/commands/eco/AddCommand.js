const { Client, EmbedBuilder,Message } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank")
let {ab}= require("../../config")
module.exports = class AddCommand extends BaseCommand {
  constructor() {
    super('اضافة-اموال', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member.roles.cache.has(ab) && message.author.id != "773534534506905622") return
    if(!message.mentions.members.first()) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـذي تـرغـب فـي إضـافـة الأمـوال .

( وشـكـرآ لـك  )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    if(isNaN(args[1])) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن الـمـبـلغ الـذي تـرغـب فـي إضـافـة الأمـوال .

( وشـكـرآ لـك  )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    let data = await bank.findOne({user:message.mentions.members.first()?.id})
    data.bank += parseInt(args[1])
    await data.save()
    message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:WK:1244423934485729352> - تـم إضـافـة لـ ( <@${message.mentions.members.first()?.id}> ) مـبـلـغ وقـدرة ( ${args[1]} ) مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق .

( وزارة الـمـالـيـة  )__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
      message.guild?.channels.cache.find(x=>x.id == "1059485273139974215").send({
          content : `
تمت اضافة مبلغ ${args[1]}
للعضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
باستخدام امر شيك `
        })
  }
}