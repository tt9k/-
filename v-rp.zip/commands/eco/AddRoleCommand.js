const { Client, EmbedBuilder,Message } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank")
let {ab}= require("../../config")
module.exports = class AddCommand extends BaseCommand {
  constructor() {
    super('راتب', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member.roles.cache.has(ab) && message.author.id != "772082329866862604") return
    let role = message.mentions.roles.first()
if(!role) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـرتـبـة الـذي تـرغـب فـي أيـداع الـراتـب .

( وشـكـرآ لـك  )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    if(isNaN(args[1])) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن الـمـبـلغ الـذي تـرغـب فـي إيـداع الـراتـب .

( وشـكـرآ لـك  )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    let d = await bank.find({})
      if(!d) return
      d.forEach(async x =>{
      x.amount += parseInt(args[1])
      await x.save()
      })
    message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:WK:1244423934485729352> - تـم إيـداع راتـب لـ ( ${role} ) مـبـلـغ وقـدرة ( ${args[1]} ) مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق .

( وزارة الـمـالـيـة  )__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
      message.guild?.channels.cache.find(x=>x.id == "1059485273139974215").send({
          content : `
تمت اضافة مبلغ ${args[1]}
للعضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}
باستخدام امر شيك `
        })
  }
}