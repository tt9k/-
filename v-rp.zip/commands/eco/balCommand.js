const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, ButtonBuilder, ButtonStyle, TextInputStyle } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require('../../models/bank');

module.exports = class EcoCommand extends BaseCommand {
  constructor() {
    super('bank', 'eco', []);
    this.messageId = null;
    this.channelId = null;
  }

  async run(client, message, args) {
    if (!message.member.permissions.has('Administrator')) {
      return message.reply('لا يمكنك استخدام هذا الأمر.');
    }

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('bank-menu')
        .setPlaceholder('البنك')
        .addOptions([
          { label: 'رصيدي', description: 'عرض رصيدك البنكي', value: 'balance', emoji: '<:emoji_187:1253719953501061341>' },
          { label: 'تحويل', description: 'تحويل الأموال لمستخدم آخر', value: 'transfer', emoji: '<:emoji_187:1253719953501061341>' },
          { label: 'سحب', description: 'سحب الأموال من البنك', value: 'withdraw', emoji: '<:emoji_187:1253719953501061341>' },
          { label: 'إيداع', description: 'إيداع الأموال في البنك', value: 'deposit', emoji: '<:emoji_187:1253719953501061341>' },
          { label: 'طلب قرض', description: 'طلب قرض من البنك', value: 'loan', emoji: '<:emoji_187:1253719953501061341>' }
        ])
    );

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('نظام بنك وندر')
      .setDescription('– لوحة التحكم بالنظام بنك وندر')
      .setTimestamp()
      .setFooter({ text: 'نظام الرصيد', iconURL: 'https://cdn.discordapp.com/attachments/1207016246604861511/1255058079192453170/0f4148007694db93.gif?ex=667bbf6b&is=667a6deb&hm=882509b5cd5263cb1ba8a052f4ac56a49a0cb1f6b93cc7077a116e7069f30ce9&' })
      .setImage('https://media.discordapp.net/attachments/1254977166622588928/1255420834873610310/IMG_8605.png?ex=667d1143&is=667bbfc3&hm=43c9aa4f34b77b0910a4d07f07398dd29c10803bd8f2c8f90432bf4b898d8537&=&format=webp&quality=lossless');

    const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });
    this.messageId = sentMessage.id;
    this.channelId = message.channel.id;

    const filter = i => i.customId === 'bank-menu' && ['balance', 'transfer', 'withdraw', 'deposit', 'loan'].includes(i.values[0]);
    const collector = message.channel.createMessageComponentCollector({ filter });

    collector.on('collect', async i => {
      const action = i.values[0];
      if (action === 'balance') {
        if (i.replied || i.deferred) {
          return;
        }
        await i.deferReply({ ephemeral: true });

        const data = await bank.findOne({ user: i.user.id });

        if (!data) {
          await i.followUp({ content: 'انت لا تمتلك حساب بنكي', ephemeral: true });
        } else {
          const embed = new EmbedBuilder()
            .setColor(0x8A2BE2)
            .setThumbnail(client.user.avatarURL())
            .setTimestamp()
            .setDescription(`**__<:1k_rajhi:1248609123189129328> — أهلاً بك في مصرف الراجحي — <:1k_rajhi:1248609123189129328>
<:oLd:1247945595977732098> — إشعار برصيد الحساب — <:oLd:1247945595977732098>

<:emoji_161:1248609475850403861> — عزيزي العميل ( <@${i.user.id}> ) . 

<:emoji_140:1248609472763658283> — رصيدك في الكاش : ( ${data.amount} ) . 

<:emoji_190:1248609470620373066> — رصيدك في البنك : ( ${data.bank} ) . 

<:emoji_139:1248609468816560158> — إجمالي الرصيد : ( ${data.amount + data.bank} ) . 

<:1k_rajhi:1248609123189129328> — مصرف الراجحي — <:1k_rajhi:1248609123189129328> 
 __**`);

          await i.followUp({ embeds: [embed], ephemeral: true });
        }
      } else if (action === 'transfer') {
        const modal = new ModalBuilder()
          .setCustomId('transferModal')
          .setTitle('تحويل الأموال')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('amount')
                .setLabel('المبلغ')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل المبلغ')
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('userId')
                .setLabel('معرف المستخدم')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل معرف المستخدم')
                .setRequired(true)
            )
          );

        await i.showModal(modal);
      } else if (action === 'withdraw') {
        const modal = new ModalBuilder()
          .setCustomId('withdrawModal')
          .setTitle('سحب الأموال')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('amount')
                .setLabel('المبلغ')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل المبلغ المراد سحبه')
                .setRequired(true)
            )
          );

        await i.showModal(modal);
      } else if (action === 'deposit') {
        const modal = new ModalBuilder()
          .setCustomId('depositModal')
          .setTitle('إيداع الأموال')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('amount')
                .setLabel('المبلغ')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل المبلغ المراد إيداعه')
                .setRequired(true)
            )
          );

        await i.showModal(modal);
      } else if (action === 'loan') {
        const modal = new ModalBuilder()
          .setCustomId('loanModal')
          .setTitle('طلب قرض')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('name')
                .setLabel('الاسم')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل اسمك')
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('job')
                .setLabel('الوظيفة')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل وظيفتك')
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('amount')
                .setLabel('المبلغ')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل المبلغ المطلوب')
                .setRequired(true)
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('reason')
                .setLabel('سبب طلب القرض')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل سبب طلب القرض')
                .setRequired(true)
            )
          );

        await i.showModal(modal);
      }
    });

    client.on('interactionCreate', async interaction => {
      if (!interaction.isModalSubmit()) return;

      if (interaction.replied || interaction.deferred) {
        return;
      }

      await interaction.deferReply({ ephemeral: true });

      const amount = parseInt(interaction.fields.getTextInputValue('amount'));
      if (isNaN(amount) || amount <= 0) {
        await interaction.followUp({ content: 'يرجى إدخال مبلغ صالح.', ephemeral: true });
        return;
      }

      if (interaction.customId === 'transferModal') {
        const userId = interaction.fields.getTextInputValue('userId');
        const user = await client.users.fetch(userId).catch(() => null);
        if (!user) {
          await interaction.followUp({ content: 'لم يتم العثور على المستخدم.', ephemeral: true });
          return;
        }

        const senderData = await bank.findOne({ user: interaction.user.id });
        if (!senderData || senderData.amount < amount) {
          await interaction.followUp({ content: 'رصيد غير كافٍ لإتمام التحويل.', ephemeral: true });
          return;
        }

        senderData.amount -= amount;
        await senderData.save();

        let recipientData = await bank.findOne({ user: user.id });
        if (!recipientData) {
          recipientData = new bank({ user: user.id, amount: amount, bank: 0 });
        } else {
          recipientData.amount += amount;
        }
        await recipientData.save();

        await interaction.followUp({ content: `تم تحويل ${amount} إلى ${user.username}.`, ephemeral: true });

      } else if (interaction.customId === 'withdrawModal') {
        const data = await bank.findOne({ user: interaction.user.id });
        if (!data || data.bank < amount) {
          await interaction.followUp({ content: 'رصيد غير كافٍ لإتمام السحب.', ephemeral: true });
          return;
        }

        data.bank -= amount;
        data.amount += amount;
        await data.save();

        await interaction.followUp({ content: `تم سحب ${amount} من البنك.`, ephemeral: true });

      } else if (interaction.customId === 'depositModal') {
        const data = await bank.findOne({ user: interaction.user.id });
        if (!data || data.amount < amount) {
          await interaction.followUp({ content: 'رصيد غير كافٍ لإتمام الإيداع.', ephemeral: true });
          return;
        }

        data.amount -= amount;
        data.bank += amount;
        await data.save();

        await interaction.followUp({ content: `تم إيداع ${amount} في البنك.`, ephemeral: true });

      } else if (interaction.customId === 'loanModal') {
        const name = interaction.fields.getTextInputValue('name');
        const job = interaction.fields.getTextInputValue('job');
          const reason = interaction.fields.getTextInputValue('reason');

          const loanEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('طلب قرض جديد')
            .setDescription(`**الاسم:** ${name}\n**الوظيفة:** ${job}\n**المبلغ المطلوب:** ${amount}\n**سبب طلب القرض:** ${reason}`)
            .setTimestamp();

          const acceptButton = new ButtonBuilder()
            .setCustomId('accept-loan')
            .setLabel('قبول القرض')
            .setStyle(ButtonStyle.Success);

          const rejectButton = new ButtonBuilder()
            .setCustomId('reject-loan')
            .setLabel('رفض القرض')
            .setStyle(ButtonStyle.Danger);

          const actionRow = new ActionRowBuilder().addComponents(acceptButton, rejectButton);

          const loanRequestMessage = await interaction.channel.send({ embeds: [loanEmbed], components: [actionRow] });

          const filter = i => i.customId === 'accept-loan' || i.customId === 'reject-loan';
          const collector = loanRequestMessage.createMessageComponentCollector({ filter, time: 60000 });

          collector.on('collect', async i => {
            if (i.customId === 'accept-loan') {
              let userBankData = await bank.findOne({ user: interaction.user.id });
              if (!userBankData) {
                userBankData = new bank({ user: interaction.user.id, amount: amount, bank: 0 });
              } else {
                userBankData.amount += amount;
              }
              await userBankData.save();

              await i.update({ content: 'تمت الموافقة على القرض وتم إضافة المبلغ إلى حساب المستخدم.', embeds: [], components: [] });

              const user = await client.users.fetch(interaction.user.id);
            await user.send(`تمت الموافقة على طلب القرض الخاص بك. تم إضافة ${amount} إلى رصيدك.`);

          } else if (i.customId === 'reject-loan') {
            await i.update({ content: 'تم رفض طلب القرض.', embeds: [], components: [] });

            const user = await client.users.fetch(interaction.user.id);
            await user.send(`تم رفض طلب القرض الخاص بك.`);
          }
        });

        collector.on('end', collected => {
          if (collected.size === 0) {
            loanRequestMessage.edit({ content: 'انتهى الوقت المخصص للرد على طلب القرض.', embeds: [], components: [] });
          }
        });

        await interaction.followUp({ content: 'تم إرسال طلب القرض للإدارة.', ephemeral: true });
      }
    });
  }
};
