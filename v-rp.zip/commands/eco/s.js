const { Client, Message, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Bank = require('../../models/bank');
const mongoose = require('mongoose');

module.exports = class StealCommand extends BaseCommand {
  constructor() {
    super('سرقة', 'eco', []);
    this.stealRequirements = {
      "بقالة": { min: 1000, max: 3000 },
      "بنك": { min: 20000, max: 25000 },
      "مرقص": { min: 10000, max: 20000 },
      "الكهرب": { min: 8000, max: 15000 },
      "المتحف": { min: 8000, max: 25000 },
      "المجوهرات": { min: 10000, max: 23000 },
      "محل ملابس ": { min: 2500, max: 5000 },
      "مصنع الخيوط": { min: 3000, max: 110000 },
      //تقدر تضيف سرقات اضافيه 
    };
  }

  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    const messagesToDelete = [];

    const requestItemEmbed = new EmbedBuilder()
      .setTitle('سرقة')
      .setDescription('ما هو العنصر الذي ترغب في سرقته؟')
      .setColor('#0000FF'); 

    const itemRequestMessage = await message.reply({ embeds: [requestItemEmbed] });
    messagesToDelete.push(itemRequestMessage);

    const filter = response => response.author.id === message.author.id;
    const collectedItem = await message.channel.awaitMessages({ filter, max: 1, time: 60000, errors: ['time'] });

    const itemToSteal = collectedItem.first().content.toLowerCase();
    messagesToDelete.push(collectedItem.first());
    if (!this.stealRequirements[itemToSteal]) {
      const invalidItemEmbed = new EmbedBuilder()
        .setTitle('خطأ')
        .setDescription('هذا العنصر لا يمكن سرقته.')
        .setColor('#FF0000'); 
      const invalidItemMessage = await message.reply({ embeds: [invalidItemEmbed] });
      messagesToDelete.push(invalidItemMessage);
      return this.cleanupMessages(messagesToDelete);
    }

    const requestImageEmbed = new EmbedBuilder()
      .setTitle('صورة الموقع')
      .setDescription('الرجاء إرسال صورة لموقع السرقة.')
      .setColor('#0000FF'); 

    const imageRequestMessage = await message.reply({ embeds: [requestImageEmbed] });
    messagesToDelete.push(imageRequestMessage);

    const imageFilter = response => response.author.id === message.author.id && response.attachments.size > 0;
    const collectedImage = await message.channel.awaitMessages({ imageFilter, max: 1, time: 60000, errors: ['time'] });

    const locationImage = collectedImage.first().attachments.first();
    messagesToDelete.push(collectedImage.first());

    const puzzleEmbed = new EmbedBuilder()
      .setTitle('لغز')
      .setDescription('سوف تظهر الأحرف تباعاً، عليك تذكر الأحرف. بعد ظهور 6 أحرف، ستظهر لك أزرار تحتوي على أحرف عشوائية، اختر الأحرف التي ظهرت بالترتيب الصحيح.')
      .setColor('#0000FF');

    const puzzleMessage = await message.author.send({ embeds: [puzzleEmbed] });

    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let puzzleLetters = '';
    for (let i = 0; i < 6; i++) {
      const randomLetter = letters[Math.floor(Math.random() * letters.length)];
      puzzleLetters += randomLetter;
      await new Promise(resolve => setTimeout(resolve, 4000));
      await puzzleMessage.edit({ embeds: [puzzleEmbed.setDescription(`الحرف رقم ${i + 1}: ${randomLetter}`)] });
    }

    const buttonRows = [];
    let buttonRow = new ActionRowBuilder();
    const usedIds = new Set();

    for (let i = 0; i < 25; i++) {
      let randomLetter;
      do {
        randomLetter = letters[Math.floor(Math.random() * letters.length)];
      } while (usedIds.has(randomLetter));

      usedIds.add(randomLetter);

      const button = new ButtonBuilder()
        .setCustomId(randomLetter)
        .setLabel(randomLetter)
        .setStyle(ButtonStyle.Primary);
      buttonRow.addComponents(button);
      if ((i + 1) % 5 === 0) {
        buttonRows.push(buttonRow);
        buttonRow = new ActionRowBuilder();
      }
    }

    const buttonMessage = await message.author.send({ content: 'اختر الأحرف التي ظهرت بالترتيب الصحيح:', components: buttonRows });

    const collector = buttonMessage.createMessageComponentCollector({ filter: interaction => interaction.user.id === message.author.id, max: 6, time: 60000 });

    let selectedLetters = '';
    collector.on('collect', async buttonInteraction => {
      selectedLetters += buttonInteraction.customId;
      await buttonInteraction.update({ content: `تم اختيار: ${selectedLetters}`, components: buttonRows });
    });

    collector.on('end', async collected => {
      if (selectedLetters.split('').sort().join('') === puzzleLetters.split('').sort().join('')) {
        const successEmbed = new EmbedBuilder()
          .setTitle('نجاح')
          .setDescription('تم حل اللغز بنجاح! الأموال الآن رسمية.')
          .setColor('#00FF00'); 

        await message.author.send({ embeds: [successEmbed] });

        let userData = await Bank.findOne({ user: message.author.id });
        if (!userData) {
          userData = new Bank({
            user: message.author.id,
            amount: 0,
          });
        }
        userData.amount += Math.floor(Math.random() * (this.stealRequirements[itemToSteal].max - this.stealRequirements[itemToSteal].min + 1)) + this.stealRequirements[itemToSteal].min;
        await userData.save();

        const stealChannel = client.channels.cache.get("1259927864879616264");
        if (stealChannel) {
          const embed = new EmbedBuilder()
            .setTitle("تفاصيل السرقة")
            .setDescription(`السارق: ${message.author}\nالمبلغ المسروق: ${userData.amount}`)
            .setTimestamp();

          const imageAttachment = new AttachmentBuilder(locationImage.url);
          stealChannel.send({ embeds: [embed], files: [imageAttachment] });
        }
      } else {
        const failureEmbed = new EmbedBuilder()
          .setTitle('فشل')
          .setDescription('فشلت عملية السرقة بسبب الحروف غير الصحيحة.')
          .setColor('#FF0000'); 

        await message.author.send({ embeds: [failureEmbed] });
      }

      this.cleanupMessages(messagesToDelete);
    });
  }

  async cleanupMessages(messages) {
    for (const msg of messages) {
      try {
        await msg.delete();
      } catch (error) {
        console.error('Failed to delete message:', error);
      }
    }
  }
};
