// @ts-nocheck
const { SelectMenuBuilder, SelectMenuOptionBuilder } = require('@discordjs/builders');
const { Client, EmbedBuilder , Message, ActionRowBuilder } = require('discord.js');
const { mo5Role } = require('../../config');
const bank = require('../../models/bank');
const BaseCommand = require('../../utils/structures/BaseCommand');
const history = require("../../models/history")
module.exports = class Mo5alafaCommand extends BaseCommand {
  constructor() {
    super('مخالفة', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    
if(!message.member?.roles.cache.has(mo5Role) &&  message.author.id != "489501373499572224") return;
let member = message.mentions.members.first()
if(!member) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـعـسـكـري .

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو الـذي تـرغـب فـي مـخـالـفـتـة .

( وشـكرآ لـك )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    let bankac = await bank.findOne({user:member?.id})
    let ob = [{
      name : "تفحيط",
      price : "1000"
    },{
      name : "سرعة عالية",
      price : "100"
    },{
      name : `الاصطدام بمركبة حكومية`,
      price : "250"
    },{
      name : "وقوف خاطئ",
      price : "250"
    },{
      name : "ازعاج السلطات",
      price : "500"
    },{
      name : "هروب من الشرطة",
      price : "1000"
    },{
      name : "عكس السير",
      price : "1500"
    },{
      name : "الاستهزاء برجل الامن",
      price : "100"
    },{
      name : "وقوف المركبة او تحركها فوق الرصيف",
      price : "1000"
    },{
      name : " تخريب الممتلكات العامة",
      price : "400"
    },{
      name : "تضليل المركبة",
      price : "300"
    },{
      name : " قطع الاشارة الضوئية",
      price : "2000"
    },{
      name : "عدم وجود لوحة خلفية",
      price : "2500"
    },{
      name :"تشوه بصري",
      price : "200"
    },{
      name : "سوء استخدام منبه المركبة ( البوري)",
      price : "100"
    },{
      name : "وضع تجاليد على المركبة",
      price : "150"
    },{
      name : "وضع اشياء داخل المركبة تعيق رؤية السائق",
      price : "50"
    },{
      name : "عدم وجود هوية وطنية",
      price : "500"
    },{
      name : "تعديل على هيكل المركبة",
      price : "250"
    },{
      name : "رشوة موضف حكومي",
      price : "2000"
    },{
      name : "القيادة تحت تآثير مسكر",
      price : "1500"
    }
  ]
    let neww = []
    ob.forEach((x,i)=>{
      let y = new SelectMenuOptionBuilder()
      .setLabel(x.name)
      .setValue(x.price+`_${i}`);
      neww.push(y)
    })
    
    let row = new ActionRowBuilder()
    .addComponents(
      new SelectMenuBuilder()
      .setMaxValues(1)
      .setCustomId("s1")
      .setPlaceholder("أخـتـر نـوع الـمـخـالـفـة")
      .addOptions(neww)
    )
    message.reply({components: [row]})
    const filter = (interaction) => interaction.customId === 's1' && interaction.user.id === message.author.id;
message.channel.awaitMessageComponent({ filter, time: 15000 })
  .then(async interaction =>{
    interaction.update({components:[],embeds:[new EmbedBuilder ().setDescription(`**__<:emoji_117:1253703889014886411> - تـم رصـد مـخـالـفـة .

<:A69:1257157369545228311> - الـعـسـكـري : ${message.member} .

<:pp721:1257157453028786307> - الـمـخـالـف : ${member}

<:T5:1257157539758346310> - نـوع الـمـخـالـفـة : ${ob[interaction.values[0].split("_")[1]].name} .

<:emoji_171:1257173941936459867> - سـعـر  الـمـخـالـفـة : ${interaction.values[0].split("_")[0]} .__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
member.send({embeds:[new EmbedBuilder ().setDescription(`**__<:emoji_117:1253703889014886411> -  تـم رصـد مـخـالـفـة .

<:A69:1257157369545228311> - الـعـسـكـري : ${message.member} .

<:T5:1257157539758346310> - نـوع الـمـخـالـفـة : ${ob[interaction.values[0].split("_")[1]].name} .

<:emoji_171:1257173941936459867> - سـعـر  الـمـخـالـفـة : ${interaction.values[0].split("_")[0]} .

<:pp186:1257157977337761833> - نـرجـوا مـنـك سـداد الـمـخـالـفـة تـجـنـبـآ لإيـقـاف الـخـدمـات .__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]}).catch(console.log)
    bankac.bank -= parseInt(interaction.values[0].split("_")[0])
    await bankac.save()
      let d = new history({
    user : member.id,
    reason : ob[interaction.values[0].split("_")[1]].name
  })
  await d.save()
  })
  .catch(console.error);

  }
}