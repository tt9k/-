const { Client, Message, EmbedBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const points = require('../../models/points');

module.exports = class AdafaCommand extends BaseCommand {
  constructor() {
    super('اضافة-نقاط', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has("1244408813101256807") && message.author.id != "1085228926894358539") return;
    let member = message.mentions.members.first()
if(!member) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـذي تـرغـب فـي إضـافـة الـنـقـاط .

( وشـكـرآ لـك  )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    if(isNaN(args[1])) return message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن الـنـقـاط الـذي تـرغـب فـي إضـافـة الـنـقـاط .

( وشـكـرآ لـك  )__**`).setColor("DarkRed").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    async function addPoints(id,am){
      let data = await points.findOne({user : id})
      if(!data) data = new points({user : id})
      data.plus +=am;
      await data.save()
    }
    await addPoints(member.id,parseInt(args[1]))
    message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:WK:1244423934485729352> - تـم إضـافـة لـ ( ${member} ) نـقـاط وقـدرهـا ( ${args[1]} ) بـنـجـاح .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
  client.channels.cache.get("1257583016881164318").send({
      embeds : [
        new EmbedBuilder()
        .setColor("Random")
        .setTimestamp()
        .setFooter({iconURL : client.user?.displayAvatarURL(),text : client.user?.username})
        .setDescription(`
تم اضافه نقاط

الإداري : ${member}
        
السبب : اضافة من اونر
`)
      ]
    })
  }
}