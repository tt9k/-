const { Client, EmbedBuilder ,Message } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank")
module.exports = class ZeroCommand extends BaseCommand {
  constructor() {
    super('تصفير-الكل', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has("1244408813101256807") && message.author.id != "1085228926894358539") return;
      let d = await bank.find({})
      if(!d) return
      if(!d[0]) return
      d.forEach(async x=>{
          x.amount = 0
          x.bank = 0
          await x.save()
      })
      message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:WK:1244423934485729352> - تـم تـصـفـيـر جـمـيـع أمـوال وولـف كـيـنـق بـالـكـامـل مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق .

( وزارة الـمـالـيـة )__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
      message.guild?.channels.cache.find(x=>x.id == "1244408949470531734").send({
          content : `
تم تصفير اموال الكل
بواسطة الادمن : ${message.member}`
        })
  }
}