const { Client, Message, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const points = require('../../models/points');

module.exports = class NeqateCommand extends BaseCommand {
  constructor() {
    super('نقاط', 'eco', []);
  }

  async run(client, message, args) {
    if (!message.member.roles.cache.has("1198059405296549918")) return;

    const embed = new EmbedBuilder()
      .setColor("Gold")
      .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
      .setTimestamp()
      .setDescription(`**__ مرحبا بك في لوحه التحكم في نقاط الاداره .__**`)
      .setImage('https://media.discordapp.net/attachments/1265692209509040281/1266253833122742376/45b06a456d4c3668.png?ex=66a52307&is=66a3d187&hm=29ebd40bf087e561b6d696d3a33f1d1122155c30cbc3079e559a0ff1e7ee264d&=&format=webp&quality=lossless&width=1440&height=507');  

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('my_points')
        .setLabel('عرض نقاطك')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('<:emoji_1:1249027064342773793>'), 
      new ButtonBuilder()
        .setCustomId('admin_points')
        .setLabel('عرض نقاط إداري آخر')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('<:emoji_1:1249027064342773793>')  
    );

    let sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = async (message) => {
      const componentCollector = message.createMessageComponentCollector({ time: 3600000 });

      componentCollector.on('collect', async (interaction) => {
        if (interaction.customId === 'my_points') {
          let data = await points.findOne({ user: interaction.user.id });
          if (!data) data = new points({ user: interaction.user.id });
          const pointsEmbed = new EmbedBuilder()
            .setColor("Gold")
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setTimestamp()
            .setDescription(`**__- إسـتـعـلام نـقـاطك .

            1 - الـتـفـعـيـل : ( ${data.tafeel} ) .

            2 - الأقـيـام : ( ${data.game} ) .

            3 - الـتـكـتـات : ( ${data.ticket} ) .

            4 - الـرقـابـة : ( ${data.gms} ) .

            5 - الإضـافـيـة : ( ${data.plus} ) .

             - الإجـمـالـي : ( ${data.game + data.tafeel + data.ticket + data.gms + data.plus} ) .__**`);

          await interaction.reply({ embeds: [pointsEmbed], ephemeral: true });
        } else if (interaction.customId === 'admin_points') {
          const modal = new ModalBuilder()
            .setCustomId('adminPointsModal')
            .setTitle('عرض نقاط إداري آخر')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('adminId')
                  .setLabel('أدخل ايدي الإداري')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
              )
            );

          await interaction.showModal(modal);
        }
      });
    };

    collector(sentMessage);

    client.on(Events.MessageDelete, async (deletedMessage) => {
      if (deletedMessage.id === sentMessage.id) {
        const newSentMessage = await message.channel.send({ embeds: [embed], components: [row] });
        sentMessage = newSentMessage;
        await newSentMessage.react('✅');
        collector(newSentMessage);
      }
    });

    client.on(Events.InteractionCreate, async interaction => {
      if (interaction.isModalSubmit()) {
        const modalId = interaction.customId;
        await interaction.deferReply({ ephemeral: true });

        if (modalId === 'adminPointsModal') {
          const adminId = interaction.fields.getTextInputValue('adminId');
          let data = await points.findOne({ user: adminId });
          if (!data) data = new points({ user: adminId });

          const adminPointsEmbed = new EmbedBuilder()
            .setColor("Gold")
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setTimestamp()
            .setDescription(`**__ - إسـتـعـلام نـقـاط الإداري ( ${adminId} ) .


1 - الـتـفـعـيـل : ( ${data.tafeel} ) .

2 - الأقـيـام : ( ${data.game} ) .

3 - الـتـكـتـات : ( ${data.ticket} ) .

4 - الـرقـابـة : ( ${data.gms} ) .

5 - الإضـافـيـة : ( ${data.plus} ) .

 - الإجـمـالـي : ( ${data.game + data.tafeel + data.ticket + data.gms + data.plus} ) .__**`);

          await interaction.editReply({ embeds: [adminPointsEmbed], ephemeral: true });
        }
      }
    });
  }
};
