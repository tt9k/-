const { Client, Message, EmbedBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const points = require('../../models/points');

module.exports = class KhasemCommand extends BaseCommand {
  constructor() {
    super('تصفير-الجميع', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if(!message.member.roles.cache.has("1244408813101256807")) return;   
    await points.deleteMany()
    message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:WK:1244423934485729352> - تـم تـصـفـيـر جـمـيـع الـنـقـاط الإداريـة بـنـجـاح .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
    client.channels.cache.get("1257583016881164318").send({
      embeds : [
        new EmbedBuilder()
        .setColor("Random")
        .setTimestamp()
        .setFooter({iconURL : client.user?.displayAvatarURL(),text : client.user?.username})
        .setDescription(`
تم تصفير الكل نقاط
        
السبب : تصفير الكل
`)
      ]
    })
  }
}