const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Hoe = require('../../models/Hoe');

module.exports = class DeleteIdentityCommand extends BaseCommand {
  constructor() {
    super('deleteIdentity', 'admin', []);
  }

  async run(client, message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.channel.send('ليس لديك الصلاحيات اللازمة لاستخدام هذا الأمر.');
    }

    const memberId = args[0];
    const reason = args.slice(1).join(' ');

    if (!memberId) {
      return message.channel.send('يرجى تحديد ايدي العضو الذي تريد حذف هويته.');
    }

    if (!reason) {
      return message.channel.send('يرجى تحديد سبب لحذف الهوية.');
    }

    try {
      const identity = await Hoe.findOneAndDelete({ memberId: memberId });

      if (!identity) {
        return message.channel.send('لم يتم العثور على هوية لهذا العضو.');
      }

      const member = await message.guild.members.fetch(memberId);

      if (member) {
        const dmChannel = await member.createDM();

        const embed = new EmbedBuilder()
          .setColor('Red')
          .setTitle('تم حذف هويتك')
          .setDescription(`تم حذف هويتك من النظام لسبب: ${reason}`);

        await dmChannel.send({ embeds: [embed] });
      } else {
        return message.channel.send('لم يتم العثور على العضو في السيرفر.');
      }

      await message.channel.send(`تم حذف هوية العضو ${memberId} بنجاح.`);

    } catch (error) {
      console.error(error);
      await message.channel.send('حدث خطأ أثناء محاولة حذف الهوية.');
    }
  }
};
