const { Client, GatewayIntentBits, PermissionsBitField, EmbedBuilder, ActionRowBuilder, SelectMenuBuilder, InteractionType } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Hoe = require('../../models/Hoe');

module.exports = class IdentityCommand extends BaseCommand {
  constructor() {
    super('identity', 'general', []);
  }

  async run(client, message, args) {
    const identity = await Hoe.findOne({ memberId: message.author.id });

    if (!identity) {
      return message.channel.send('ليس لديك هوية.');
    }

    const identityEmbed = new EmbedBuilder()
      .setColor('Blue')
      .setTitle('هويتك')
      .setThumbnail(identity.profilePictureUrl)
      .addFields(
        { name: 'الاسم الأول', value: identity.firstName, inline: true },
        { name: 'اسم العائلة', value: identity.lastName, inline: true },
        { name: 'الجنس', value: identity.sex, inline: true },
        { name: 'تاريخ الميلاد', value: identity.dob, inline: true },
        { name: 'الجنسية', value: identity.nationality, inline: true },
        { name: 'مكان الميلاد', value: identity.birth, inline: true },
        { name: 'رقم الهوية', value: identity.number, inline: true },
        { name: 'القسم', value: identity.department, inline: true }
      );

    await message.channel.send({ embeds: [identityEmbed] });
  }
};
