const { Client, GatewayIntentBits, PermissionsBitField, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, InteractionType } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Hoe = require('../../models/Hoe');

module.exports = class A3lameCommand extends BaseCommand {
  constructor() {
    super('h', 'sgsdg23', []);
  }

  async run(client, message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.channel.send('ليس لديك الصلاحيات اللازمة لاستخدام هذا الأمر.');
    }

    message.delete();

    const embed = new EmbedBuilder()
      .setColor('White')
      .setDescription('اضغط لإنشاء هوية:')
      .setImage('https://media.discordapp.net/attachments/1249856058642534402/1249856589725175840/Picsart_24-05-25_14-49-35-697.jpg?ex=66828868&is=668136e8&hm=eb16a7cf09570ecfcbe506d5d32728fe8e6a1ecb44722760894db78d9a8d66a4&=&format=webp'); // يمتيك تغير الا رابط الصورة الي تبيه

    const row = new ActionRowBuilder()
      .addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('select_department')
          .setPlaceholder('إنشاء هوية')
          .addOptions([
            {
              label: 'إنشاء هوية',
              value: 'police_department',
              emoji: '<:Police_BCM:1250962880078282793>',
            },
          ]),
      );

    const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = (interaction) => interaction.type === InteractionType.MessageComponent && interaction.customId === 'select_department';
    const collector = sentMessage.createMessageComponentCollector({ filter });

    collector.on('collect', async (interaction) => {
      const selectedDepartment = interaction.values[0];

      if (interaction.replied || interaction.deferred) return;

      await interaction.deferUpdate();

      const existingIdentity = await Hoe.findOne({ memberId: interaction.user.id });
      if (existingIdentity) {
        return interaction.followUp({ content: 'لديك هوية بالفعل.', ephemeral: true });
      }

      const questions = [
        '👤 - الاسم الأول: ',
        '👤 - اسم العائلة: ',
        '👤 - الجنس: ',
        '🎂 - تاريخ الميلاد: ',
        '🌍 - الجنسية: ',
        '🏙️ - مكان الميلاد: ',
        '🔢 - رقم الهوية: ',
        '📷 - الرجاء إرسال صورة شخصية: '
      ];
      const answers = [];
      let profilePictureUrl = '';

      try {
        const dmChannel = await interaction.user.createDM();

        for (const question of questions) {
          const questionEmbed = new EmbedBuilder().setColor('White').setDescription(question);
          await dmChannel.send({ embeds: [questionEmbed] });

          if (question === '📷 - الرجاء إرسال صورة شخصية: ') {
            const collected = await dmChannel.awaitMessages({ max: 1, time: 60000, errors: ['time'] });
            const attachment = collected.first().attachments.first();
            if (attachment) {
              profilePictureUrl = attachment.url;
            } else {
              await dmChannel.send('لم يتم إرسال صورة شخصية. الرجاء إعادة المحاولة.');
              return;
            }
          } else {
            const collected = await dmChannel.awaitMessages({ max: 1, time: 60000, errors: ['time'] });
            const answer = collected.first().content;
            answers.push(answer);
          }
        }

        const [firstName, lastName, sex, dob, nationality, birth, number] = answers;

        const identity = new Hoe({
          memberId: interaction.user.id,
          department: selectedDepartment,
          firstName,
          lastName,
          sex,
          dob,
          nationality,
          birth,
          number,
          profilePictureUrl
        });

        await identity.save();

        const roleID = '1216855125285408898'; // هنا تحط ايدي رتبه يمتلك هوية 
        const guildMember = await message.guild.members.fetch(interaction.user.id);
        if (guildMember) {
          await guildMember.roles.add(roleID).catch(console.error);
          await dmChannel.send('تم إنشاء هويتك بنجاح.');
        } else {
          console.error('لم يتم العثور على العضو');
        }

        const infoEmbed = new EmbedBuilder()
          .setColor('White')
          .setTitle('هوية جديده ')
          .addFields(
            { name: 'الاسم الأول', value: firstName },
            { name: 'اسم العائلة', value: lastName },
            { name: 'الجنس', value: sex },
            { name: 'تاريخ الميلاد', value: dob },
            { name: 'الجنسية', value: nationality },
            { name: 'مكان الميلاد', value: birth },
            { name: 'رقم الهوية', value: number },
          )
          .setImage(profilePictureUrl);

        const channel = await client.channels.fetch('1259927864879616264');
        await channel.send({ embeds: [infoEmbed] });

      } catch (error) {
        console.error(error);
        await interaction.user.send('حدث خطأ أثناء إنشاء الهوية.');
      }
    });
  }
};
