const { Client, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const Points = require('../../models/Points');
const BaseCommand = require('../../utils/structures/BaseCommand');

module.exports = class Mo5alafaCommand extends BaseCommand {
  constructor() {
    super('عمليات', 'eco', []);
  }

  async run(client, message, args) {
    if (!message.member.permissions.has('ADMINISTRATOR')) return;

    const embed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('مركز العمليات')
      .setDescription(`
- السلام عليكم حياك عزيزي العسكري

- لتسجيل دخول اضغط على زر تسجيل الدخول

- لتسجيل خروج اضغط زر تسجيل خروج 

- لعرض نقاطك اضغط زر عرض نقاطي

- لعرض عدد العساكر المسجلين دخول اضغط زر عرض عدد العساكر`);

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('login')
          .setLabel('تسجيل دخول')
          .setStyle(ButtonStyle.Primary)
          .setEmoji('🔓'), 
        new ButtonBuilder()
          .setCustomId('logout')
          .setLabel('تسجيل خروج')
          .setStyle(ButtonStyle.Danger)
          .setEmoji('🔒'), 
        new ButtonBuilder()
          .setCustomId('points')
          .setLabel('عرض نقاطي')
          .setStyle(ButtonStyle.Secondary)
          .setEmoji('💎'),
        new ButtonBuilder()
          .setCustomId('checkLoginCount')
          .setLabel('عرض عدد العساكر')
          .setStyle(ButtonStyle.Success)
          .setEmoji('👥')
      );

    const msg = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = i => ['login', 'logout', 'points', 'checkLoginCount'].includes(i.customId);
    const collector = msg.createMessageComponentCollector({ filter });

    collector.on('collect', async i => {
      try {
        if (i.customId === 'login') {
          const userPoints = await Points.findOne({ userId: i.user.id });

          if (userPoints && userPoints.loginTimestamp) {
            await i.reply({ content: `أنت مسجل دخول بالفعل.`, ephemeral: true });
          } else {
            await Points.updateOne(
              { userId: i.user.id },
              { $inc: { points: 1 }, loginTimestamp: new Date() },
              { upsert: true }
            );
            await i.reply({ content: `تم تسجيل دخولك بنجاح!`, ephemeral: true });
            await updateLoginMessage(client);
          }
        } else if (i.customId === 'logout') {
          const userPoints = await Points.findOne({ userId: i.user.id });

          if (!userPoints || !userPoints.loginTimestamp) {
            await i.reply({ content: `أنت لست مسجل دخول.`, ephemeral: true });
          } else {
            const currentTime = new Date();
            const timeDiff = (currentTime - userPoints.loginTimestamp) / 1000;
            const hours = Math.floor(timeDiff / 3600);
            const minutes = Math.floor((timeDiff % 3600) / 60);
            const seconds = Math.floor(timeDiff % 60);

            if (timeDiff < 600) {
              await Points.updateOne(
                { userId: i.user.id },
                { $inc: { points: -1 }, $unset: { loginTimestamp: "" } }
              );
            } else {
              await Points.updateOne(
                { userId: i.user.id },
                { $unset: { loginTimestamp: "" } }
              );
            }

            await updateLoginMessage(client);

            const presenceTime = `${hours} ساعات، ${minutes} دقائق، ${seconds} ثواني`;
            const channel = client.channels.cache.get('1259175254916333598'); // هنا تححط ايدي الروم الي يكون لوق تسجيل خروج
            if (channel) {
              const logoutEmbed = new EmbedBuilder()
                .setColor('#ff0000') 
                .setTitle('معلومات تسجيل الخروج')
                .setDescription(`<@${i.user.id}> كان متواجدًا لمدة ${presenceTime}.`);
              await channel.send({ embeds: [logoutEmbed] });
            }

            await i.reply({ content: `تم تسجيل خروجك بنجاح!`, ephemeral: true });
          }
        } else if (i.customId === 'points') {
          const userPoints = await Points.findOne({ userId: i.user.id });

          if (userPoints) {
            await i.reply({ content: `لديك ${userPoints.points} نقطة.`, ephemeral: true });
          } else {
            await i.reply({ content: `لا تمتلك نقاط حاليًا.`, ephemeral: true });
          }
        } else if (i.customId === 'checkLoginCount') {
          const users = await Points.find({ loginTimestamp: { $exists: true } });
          const userList = users.map(user => `<@${user.userId}> ✅`).join('\n') || 'لا يوجد عساكر حاليا .';
          const loginCountEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle(`عدد العساكر المسجلين دخول: ${users.length}`)
            .setDescription(userList);

          await i.reply({ embeds: [loginCountEmbed], ephemeral: true });
        }
      } catch (error) {
        console.error('Error handling interaction:', error);
        try {
          if (!i.replied) {
            await i.reply({ content: 'حدث خطأ أثناء معالجة تفاعلك. الرجاء المحاولة مرة أخرى.', ephemeral: true });
          }
        } catch (replyError) {
          console.error('Error sending error reply:', replyError);
        }
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        msg.edit({ components: [] });
      }
    });
  }
};

async function updateLoginMessage(client) {
  const users = await Points.find({ loginTimestamp: { $exists: true } });
  const userList = users.map(user => `<@${user.userId}> ✅`).join('\n') || 'لا يوجد عساكر حاليا .';
  const loginChannel = client.channels.cache.get('1265692245458419879'); // لا تغير شي هنا

  if (loginChannel) {
    const loginEmbed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle(`عدد العساكر : ${users.length}`)
      .setDescription(userList);

    const messages = await loginChannel.messages.fetch({ limit: 10 });
    const botMessage = messages.find(msg => msg.author.id === client.user.id);

    if (botMessage) {
      await botMessage.edit({ embeds: [loginEmbed] });
    } else {
      await loginChannel.send({ embeds: [loginEmbed] });
    }
  }

  await checkAndSendSpecialMessages(client, users.length);
}

async function checkAndSendSpecialMessages(client, userCount) {
}
