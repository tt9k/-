const { Client , EmbedBuilder , Message } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank")
module.exports = class newZeroCommand extends BaseCommand {
  constructor() {
    super('تصفير-اموال', 'eco', []);
  }
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has("1244408813101256807") && message.author.id != "1085228926894358539") return;
      if(!message.mentions.members.first()) return
      let d = await bank.findOne({user : message.mentions.members.first().id})
      if(!d) return message.reply({content : "لا يملك العضو حساب بنكي"})
      d.amount = 0
            d.bank = 0

      await d.save()
      message.reply({embeds:[new EmbedBuilder ().setDescription(`**__<:A69:1257157369545228311> - عـزيـزي الـمـسـؤول . 

<:WK:1244423934485729352> - تـم تـصـفـيـر حسـاب الـعـضـو الـمـصـرفـي بـنـجـاح مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق .

( وزارة الـمـالـيـة )__**`).setColor("Gold").setAuthor({name: message.author.username,iconURL: message.author.displayAvatarURL({dynamic:true})})]})
      message.guild?.channels.cache.find(x=>x.id == "1244408949470531734").send({
          content : `
تم تصفير اموال العضو : ${message.mentions.members.first()}
بواسطة الادمن : ${message.member}`
        })
  }
}