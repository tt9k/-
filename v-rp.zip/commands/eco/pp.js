const { Client, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionsBitField } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const Points = require('../../models/Points');
const { moRole } = require('../../config');

module.exports = class PointsCommand extends BaseCommand {
  constructor() {
    super('نظام', 'admin', []);
  }

  async run(client, message, args) {
    if (!message.member.roles.cache.has(moRole)) {
      return message.reply('لا تملك الصلاحية لتنفيذ هذا الأمر.');
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('addPoints')
        .setLabel('إضافة نقاط')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('removePoints')
        .setLabel('إزالة نقاط')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('resetPoints')
        .setLabel('تصفير النقاط')
        .setStyle(ButtonStyle.Secondary)
    );

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('نظام النقاط')
      .setDescription('اختر إجراءً')
      .setTimestamp();

    const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = i => ['addPoints', 'removePoints', 'resetPoints'].includes(i.customId);
    const collector = message.channel.createMessageComponentCollector({ filter });

    collector.on('collect', async i => {
      if (i.customId === 'addPoints') {
        const modal = new ModalBuilder()
          .setCustomId('addPointsModal')
          .setTitle('إضافة نقاط')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('userId')
                .setLabel('ID المستخدم')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل ID المستخدم')
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('points')
                .setLabel('عدد النقاط')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل عدد النقاط')
            )
          );

        await i.showModal(modal);
      } else if (i.customId === 'removePoints') {
        const modal = new ModalBuilder()
          .setCustomId('removePointsModal')
          .setTitle('إزالة نقاط')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('userId')
                .setLabel('ID المستخدم')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل ID المستخدم')
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('points')
                .setLabel('عدد النقاط')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('أدخل عدد النقاط')
            )
          );

        await i.showModal(modal);
      } else if (i.customId === 'resetPoints') {
        try {
          await Points.updateMany({}, { points: 0 });
          await i.reply({ content: 'تم تصفير جميع النقاط بنجاح.', ephemeral: true });
        } catch (error) {
          console.error(error);
          await i.reply({ content: 'حدث خطأ أثناء تصفير النقاط.', ephemeral: true });
        }
      }
    });

    client.on('interactionCreate', async interaction => {
      if (!interaction.isModalSubmit()) return;

      await interaction.deferReply({ ephemeral: true });

      const userId = interaction.fields.getTextInputValue('userId');
      const points = parseInt(interaction.fields.getTextInputValue('points'));

      if (isNaN(points) || points <= 0) {
        return interaction.followUp({ content: 'يرجى تحديد عدد صحيح موجب للنقاط.', ephemeral: true });
      }

      if (interaction.customId === 'addPointsModal') {
        try {
          const userPoints = await Points.findOne({ userId });
          if (!userPoints) {
            const newPoints = new Points({ userId, points });
            await newPoints.save();
          } else {
            await Points.updateOne({ userId }, { $inc: { points } });
          }

          await interaction.followUp({ content: `تمت إضافة ${points} نقطة لـ <@${userId}> بنجاح.`, ephemeral: true });
        } catch (error) {
          console.error(error);
          await interaction.followUp({ content: 'حدث خطأ أثناء إضافة النقاط.', ephemeral: true });
        }
      } else if (interaction.customId === 'removePointsModal') {
        try {
          const userPoints = await Points.findOne({ userId });
          if (!userPoints || userPoints.points < points) {
            return interaction.followUp({ content: `لا يمكن إزالة ${points} نقطة لـ <@${userId}>، لأنه لا يملك هذا العدد من النقاط.`, ephemeral: true });
          }

          await Points.updateOne({ userId }, { $inc: { points: -points } });

          await interaction.followUp({ content: `تمت إزالة ${points} نقطة من <@${userId}> بنجاح.`, ephemeral: true });
        } catch (error) {
          console.error(error);
          await interaction.followUp({ content: 'حدث خطأ أثناء إزالة النقاط.', ephemeral: true });
        }
      }
    });

    client.on('messageDelete', async deletedMessage => {
      if (deletedMessage.id === sentMessage.id) {
        const newMessage = await message.channel.send({ embeds: [embed], components: [row] });
        sentMessage.id = newMessage.id;
      }
    });
  }
};
