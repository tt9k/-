// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const { ActionRowBuilder } = require("discord.js")
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('sendpanel', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return

let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open3')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setLabel(`قـسـم الـمـسـاعـدة`),
        new Discord.ButtonBuilder()
          .setCustomId('open4')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setLabel(`الـشـكـاوي الـعـامـة`)
      )
let embed = new Discord.EmbedBuilder()
.setColor("Gold")
.setTitle(`**${message.guild.name}**`)
.setDescription(`**__<:A69:1257157369545228311> - الـدعـم الـفـنـي .

<:pp721:1257157453028786307> - أهـلا بـك عـزيـزي الـعـضـو فـي الـدعـم الـفـنـي .

<:pp186:1257157977337761833> - فـي حـال لـديـك خـدمـة أو وجـود أسـتـفـسـار الـرجـاء الـضـغـط عـلـى قـسـم الـمـسـاعـدة .

<:pp186:1257157977337761833> - فـي حـال لـديـك شـكـوى عـلـى أحـد الأعـضـاء الـرجـاء الـضـغـط عـلـى الـشـكـاوي الـعـامـة .

<a:emoji_73:1244423923114836059> - يـرجـى الألـتـزام بـالـقـوانـيـن الـمـوضـحـة .

1 - أحـتـرام الإداري .
2 - عـدم أكـثـار الـمـنـشـن .
3 - شـرح شـكـوتـك أو إسـتـفـسـارك بـالـتـفـصـيـل .
4 - أرفـاق الأدلـة الـكـافـيـة فـي الـتـذكـرة .

<:T5:1257157539758346310> - نـرجـوا مـنـكـم الألـتـزام بـالائـحـة وعـدم مـخـالـفـتـهـا .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`)
.setImage(`https://cdn.discordapp.com/attachments/1244408859049590784/1257956572697595934/phonto-4.jpg?ex=66864ada&is=6684f95a&hm=f76a8b150d06237b38fd2ebd36a914e802a9adbcaf7e0549135dea7da682a63d&`)

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}