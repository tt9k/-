// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('sendactive', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setLabel(`تـذكـرة الـتـفـعـيـل`)
      )
let embed = new Discord.EmbedBuilder()
.setColor("Gold")
.setTitle(`**${message.guild.name}**`)
.setDescription(`**__<:A69:1257157369545228311> - قـسـم الـتـفـعـيـل .

<:pp721:1257157453028786307> - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي قـسـم الـتـفـعـيـل .

<:emoji_117:1253703889014886411>  - لـتـفـعـيـل فـي وولـف كـيـنـق الـرجـاء الـضـغـط عـلـى تـذكـرة تـفـعـيـل .

<a:MV_animated_warn:1257157757157638337>  - ويـرجـى الإلـتـزام بـالـقـوانـيـن المـوضـحـة .

1 - إحـتـرام الإداري .
2 - عـدم إكـثـار المـنـشـن بـالـتـكـت .
3 - عـدم الـتـأخـر فـي تـعـبـأة الإسـتـبـيـان وقـول الـقـسـم .

<:T5:1257157539758346310> - نـرجـوا الإلـتـزام بـالـلائـحـة وعـدم مـخـالـفـتـهـا .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`)
.setImage(`https://cdn.discordapp.com/attachments/1244408859049590784/1257956534726692884/phonto-2.jpg?ex=66864ad1&is=6684f951&hm=b008333ea7e39ead19b944d61c60f4edeeb9b0c140ffeeb6192341c417e73f65&`)
    message.channel.send({embeds: [embed] , components: [button]})
  }
}