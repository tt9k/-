// @ts-nocheck
const BaseCommand = require('../../utils/structures/BaseCommand');
const Discord = require("discord.js")
const s = require("../../config")
module.exports = class SendTicketCommand extends BaseCommand {
  constructor() {
    super('sendowner', 'ticket', []);
  }
  /**
   * 
   * @param {Discord.Client} client 
   * @param {Discord.Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(s.ticketSender)) return
    let button = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('open2')
          .setStyle(Discord.ButtonStyle.Secondary)
          .setLabel(`طـلـب أونـر`)
      )
    let embed = new Discord.EmbedBuilder()
      .setColor("Gold")
      .setTitle(`**${message.guild.name}**`)
.setDescription(`**__<:A69:1257157369545228311> - طـلـب أونـر .

<:pp721:1257157453028786307> - مـرحـبـآ بـك عـزيـزي الـعـضـو فـي طـلـب أونـر .

<:emoji_117:1253703889014886411>  - لـطـلـب أونـر فـي وولـف كـيـنـق الـرجـاء الـضـغـط عـلـى طـلـب أونـر .

<a:MV_animated_warn:1257157757157638337>  - ويـرجـى الإلـتـزام بـالـقـوانـيـن المـوضـحـة .

𝟭-  يـمـنع فـتـح الـتـكت لأسـباب تـافهه ولاتـسـتـحق تـدخـل <@&1244408813101256807> .

𝟮 - يـمـنع إكـثار الـمـنـشن والإزعـاج فـالـتـكـت .

3 – فـي حـال لـديـك شـكـوى لـم تـحل يـجـب إرفـاق الأدلـة الكـافـية إلـى أن يـتـم الـرد عـلـيـك .

4 – فـي حـال مـخـالفـتك لأحـد الـملاحـظـات مـيـوت سـاعـة .

<a:WK:1244408792024875099> – أونـريـة وولـف كـيـنـق فـي خـدمـتـكـم دائـمـآ .

( مـع تـمـنـيـاتـنـا لـكـم بـالـتـوفـيـق )__**`)
.setImage(`https://cdn.discordapp.com/attachments/1244408859049590784/1257956573091987526/phonto-7.jpg?ex=66864ada&is=6684f95a&hm=ef15ee0d94d30f4d6a4366769124ae3888dc880b02e42b99e1308fd4b07fa8e1&`)

    message.channel.send({
      embeds: [embed],
      components: [button]
    })
  }
}