const { 
  Client, 
  Message, 
  EmbedBuilder, 
  ActionRowBuilder, 
  StringSelectMenuBuilder, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle, 
  ButtonBuilder, 
  ButtonStyle,  
  Events 
} = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const proDb = require('pro.db');

module.exports = class ApplicationCommand extends BaseCommand {
  constructor() {
    super('تقديم', 'sub', []);
  }

  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply({ content: "**<:ar_MEMBRS:1251487358998544464> － آخـي الـعـضـو لايـمـكـنـك أسـتـخـدام هـذا الامـر .**" }).then(msg => {
        setTimeout(() => msg.delete(), 5000);
      });
    }

    const embed = new EmbedBuilder()
      .setTitle("تقديم وظيفة")
      .setDescription("**<:emoji_187:1253719953501061341> －𝖶𝗈𝗇𝖽𝖾𝖱 𝖢𝗂𝗍𝗒 𝖬𝖺𝗇𝖺𝗀𝖾𝗆𝖾𝗇𝗍．**\n\n" +
                      "**<:emoji_253:1253402837606731867> －اختر الوظيفة الي تبي تقدم لها．**")
      .setColor(0x4B0082)
      .setImage('https://cdn.discordapp.com/attachments/1249608943806709850/1256261012034949162/20240618_215233.png?ex=66801fbd&is=667ece3d&hm=8ceebc76051bf6dabdb0b40aa3cdc9169c378ecbc4c676cbaaaf7dfb66aa06d0&');

    const row = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('select')
        .setPlaceholder('اختر وظيفة')
        .addOptions([
          {
            label: 'إعلامي',
            description: 'تقديم لوظيفة إعلامي',
            value: 'إعلامي',
            emoji: '📰',  // إيموجي إعلامي
          },
          {
            label: 'عسكرية',
            description: 'تقديم لوظيفة عسكرية',
            value: 'عسكرية',
            emoji: '🪖',  // إيموجي عسكرية
          },
          {
            label: 'عصابة',
            description: 'تقديم لوظيفة عصابة',
            value: 'عصابة',
            emoji: '🕵️',  // إيموجي عصابة
          },
          {
            label: 'العدل',
            description: 'تقديم لوظيفة العدل',
            value: 'العدل',
            emoji: '⚖️',  // إيموجي العدل
          },
        ])
    );

    let sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const collector = async (message) => {
      const componentCollector = message.createMessageComponentCollector({ time: 3600000 });

      componentCollector.on('collect', async (interaction) => {
        if (interaction.customId === 'select') {
          const selectedOption = interaction.values[0];

          const modal = new ModalBuilder()
            .setCustomId(`applicationModal_${selectedOption}`)
            .setTitle(`تقديم لوظيفة ${selectedOption}`)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('name')
                  .setLabel('اسمك؟')
                  .setStyle(TextInputStyle.Short)
                  .setPlaceholder('أدخل اسمك')
                  .setRequired(true)
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('age')
                  .setLabel('عمرك؟')
                  .setStyle(TextInputStyle.Short)
                  .setPlaceholder('أدخل عمرك')
                  .setRequired(true)
              )
            );

          switch (selectedOption) {
            case 'إعلامي':
              modal.addComponents(
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('qualifications')
                    .setLabel('مؤهلاتك؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل مؤهلاتك')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('activity')
                    .setLabel('تفاعلك؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل تفاعلك')
                    .setRequired(true)
                )
              );
              break;

            case 'عسكرية':
              modal.addComponents(
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('reason')
                    .setLabel('سبب تقديمك للعسكرية؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل سبب تقديمك')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('experience')
                    .setLabel('خبراتك الحالية؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل خبراتك')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('sector')
                    .setLabel('القطاع؟')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('أدخل القطاع')
                    .setRequired(true)
                )
              );
              break;

            case 'عصابة':
              modal.addComponents(
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('reason')
                    .setLabel('سبب تقديمك؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل سبب تقديمك')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('experience')
                    .setLabel('خبراتك؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل خبراتك')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('gang')
                    .setLabel('العصابة؟')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('أدخل العصابة')
                    .setRequired(true)
                )
              );
              break;

            case 'العدل':
              modal.addComponents(
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('experience')
                    .setLabel('خبراتك في وزارة العدل؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل خبراتك')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('contribution')
                    .setLabel('ماذا سوف تقدم لدولة وندر ستي؟')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('أدخل ماذا سوف تقدم')
                    .setRequired(true)
                ),
                new ActionRowBuilder().addComponents(
                  new TextInputBuilder()
                    .setCustomId('role')
                    .setLabel('قاضي أم محامي؟')
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder('أدخل دورك')
                    .setRequired(true)
                )
              );
              break;
          }

          await interaction.showModal(modal);
        }
      });
    };

    collector(sentMessage);

    client.on(Events.MessageDelete, async (deletedMessage) => {
      if (deletedMessage.id === sentMessage.id) {
        const newSentMessage = await message.channel.send({ embeds: [embed], components: [row] });
        sentMessage = newSentMessage; 
        await newSentMessage.react('✅');
        collector(newSentMessage); 
      }
    });

    client.on(Events.InteractionCreate, async interaction => {
      if (!interaction.isModalSubmit()) return;

      const jobType = interaction.customId.split('_')[1];
      await interaction.deferReply({ ephemeral: true });

      try {
        const name = interaction.fields.getTextInputValue('name');
        const age = interaction.fields.getTextInputValue('age');
        let additionalFields = '';

        switch (jobType) {
          case 'إعلامي':
            const qualifications = interaction.fields.getTextInputValue('qualifications');
            const activity = interaction.fields.getTextInputValue('activity');
            additionalFields = `**مؤهلاتك:** ${qualifications}\n**تفاعلك:** ${activity}`;
            break;

          case 'عسكرية':
            const reasonMilitary = interaction.fields.getTextInputValue('reason');
            const experienceMilitary = interaction.fields.getTextInputValue('experience');
            const sector = interaction.fields.getTextInputValue('sector');
            additionalFields = `**سبب تقديمك للعسكرية:** ${reasonMilitary}\n**خبراتك الحالية:** ${experienceMilitary}\n**القطاع:** ${sector}`;
            break;

          case 'عصابة':
            const reasonGang = interaction.fields.getTextInputValue('reason');
            const experienceGang = interaction.fields.getTextInputValue('experience');
            const gang = interaction.fields.getTextInputValue('gang');
            additionalFields = `**سبب تقديمك:** ${reasonGang}\n**خبراتك:** ${experienceGang}\n**العصابة:** ${gang}`;
            break;

          case 'العدل':
            const experienceJustice = interaction.fields.getTextInputValue('experience');
            const contribution = interaction.fields.getTextInputValue('contribution');
            const role = interaction.fields.getTextInputValue('role');
            additionalFields = `**خبراتك في وزارة العدل:** ${experienceJustice}\n**ماذا سوف تقدم لدولة وندر ستي:** ${contribution}\n**قاضي أم محامي:** ${role}`;
            break;
        }

        const embed = new EmbedBuilder()
          .setTitle(`تقديم جديد لوظيفة ${jobType}`)
          .setDescription(`**اسمك:** ${name}\n**عمرك:** ${age}\n${additionalFields}`)
          .setColor(0x4B0082);

        const targetChannel = client.channels.cache.get('1259927864879616264');
        const applicationMessage = await targetChannel.send({ embeds: [embed] });

        const actionRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`accept_${applicationMessage.id}`)
            .setLabel('قبول')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`reject_${applicationMessage.id}`)
            .setLabel('رفض')
            .setStyle(ButtonStyle.Secondary)
        );

        await applicationMessage.edit({ components: [actionRow] });

        await interaction.editReply({ content: 'تم ارسال تقديمك الا الجهات المختصه نرجو منك الانتظار واذا مر اكثر من 48 ساعه ولم تاتيك رساله القبول او الرفض تستطيع التقديم مره اخرى ', ephemeral: true });

        const buttonCollector = applicationMessage.createMessageComponentCollector({ time: 3600000 });

        buttonCollector.on('collect', async (buttonInteraction) => {
          const customId = buttonInteraction.customId.split('_')[0];
          const messageId = buttonInteraction.customId.split('_')[1];

          if (messageId !== applicationMessage.id) return;

          // الرتب الي تقبل لكل تقديم
          const roleRequired = {
            'إعلامي': 'ROLE_ID_FOR_MEDIA',
            'عسكرية': 'ROLE_ID_FOR_MILITARY',
            'عصابة': 'ROLE_ID_FOR_GANG',
            'العدل': 'ROLE_ID_FOR_JUSTICE',
          };

          if (!buttonInteraction.member.roles.cache.has(roleRequired[jobType])) {
            return buttonInteraction.reply({ content: 'منت من مسؤولين قبول هادي الوظيفه.', ephemeral: true });
          }

          const applicant = await interaction.user.fetch();

          if (customId === 'accept') {
            await applicant.send(`تم قبولك لوظيفة ${jobType}. توجه لاستلام الوظيفة.`);
          } else if (customId === 'reject') {
            await applicant.send(`للأسف تم رفضك لوظيفة ${jobType}.`);
          }

          await applicationMessage.edit({ components: [] });

          buttonCollector.stop();
        });

      } catch (error) {
        console.error('Error:', error);
        await interaction.editReply({ content: 'حدث خطأ أثناء إرسال المعلومات.', ephemeral: true });
      }
    });
  }
};
