const { Client, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, TextChannel, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, Events } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const config = require("../../config");
const proDb = require('pro.db');

module.exports = class GameCommand extends BaseCommand {
  constructor() {
    super('1', 'fly', []);
  }

  async run(client, message, args) {
    try {
      if (!message.member.permissions.has('ADMINISTRATOR')) {
        return message.reply({ content: "**<:ar_MEMBRS:1251487358998544464> － آخـي الـعـضـو لايـمـكـنـك أسـتـخـدام هـذا الامـر .**" }).then(msg => {
          setTimeout(() => msg.delete(), 5000); 
        });
      }

      const embed = new EmbedBuilder()
        .setTitle("بدء رحلة جديدة")
        .setDescription(
          "**<:emoji_187:1253719953501061341> －𝖶𝗈𝗇𝖽𝖾𝖱 𝖢𝗂𝗍𝗒 𝖬𝖺𝗇𝖺𝗀𝖾𝗆𝖾𝗇𝗍．**\n\n" +
          "**<:emoji_253:1253402837606731867> －اهـلاً وسـهـلاً بـكـم فـي وحـدة الـتـحـكـم لـبـدء رحـلـة الـرجـاء الـضـغـط عـلـى بدء رحـلـة．**\n\n" +
          "<:emoji_250:1253402774004043816> －رحـلٰة سـعـيدة <:AHeart24:1242453864624689172> ．"
        )
        .setColor(0x4B0082)
        .setImage('https://cdn.discordapp.com/attachments/1249608943806709850/1256261012034949162/20240618_215233.png?ex=66801fbd&is=667ece3d&hm=8ceebc76051bf6dabdb0b40aa3cdc9169c378ecbc4c676cbaaaf7dfb66aa06d0&');

      const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('select')
          .setPlaceholder('اختر خياراً')
          .addOptions([
            {
              label: 'شرح',
              description: 'شرح كيفية بدء القيم',
              value: 'شرح',
            },
            {
              label: 'بداية',
              description: 'بدء جمع المعلومات لبدء القيم',
              value: 'بداية',
            },
          ])
      );

      let sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

      const collector = async (message) => {
        const componentCollector = message.createMessageComponentCollector({ time: 3600000 });

        componentCollector.on('collect', async (interaction) => {
          if (interaction.customId === 'select') {
            const selectedOption = interaction.values[0];

            if (selectedOption === 'شرح') {
              await interaction.reply({ content: 'https://cdn.discordapp.com/attachments/1249608938727538770/1255956899271282720/Recording_2024-06-27_214258.mp4?ex=667f0483&is=667db303&hm=b6cee8e1f0b7a5fb734dc7a5e52b1b65041af5142a6c71eebdafe323422e4062&', ephemeral: true });
            } else if (selectedOption === 'بداية') {
              const modal = new ModalBuilder()
                .setCustomId('startJourneyModal')
                .setTitle('بدء رحلة')
                .addComponents(
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('capId')
                      .setLabel('ايدي كابتن الرحلة')
                      .setStyle(TextInputStyle.Short)  
                      .setPlaceholder('أدخل ايدي كابتن الرحلة')
                      .setRequired(true)
                  ),
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('cocapId')
                      .setLabel('ايدي مساعد كابتن الرحلة')
                      .setStyle(TextInputStyle.Short) 
                      .setPlaceholder('أدخل ايدي مساعد كابتن الرحلة')
                      .setRequired(true)
                  ),
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('stime')
                      .setLabel('وقت الارسال')
                      .setStyle(TextInputStyle.Short)  
                      .setPlaceholder('أدخل وقت الارسال')
                      .setRequired(true)
                  ),
                  new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                      .setCustomId('departureTime')
                      .setLabel('موعد الاقلاع')
                      .setStyle(TextInputStyle.Short)  
                      .setPlaceholder('أدخل موعد الاقلاع')
                      .setRequired(true)
                  )
                );

              await interaction.showModal(modal);
            }
          }
        });
      };

      collector(sentMessage);

      client.on(Events.MessageDelete, async (deletedMessage) => {
        if (deletedMessage.id === sentMessage.id) {
          const newSentMessage = await message.channel.send({ embeds: [embed], components: [row] });
          sentMessage = newSentMessage; 
          await newSentMessage.react('✅');
          collector(newSentMessage);
        }
      });

      client.on(Events.InteractionCreate, async interaction => {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId === 'startJourneyModal') {
          await interaction.deferReply({ ephemeral: true });

          try {
            const capId = interaction.fields.getTextInputValue('capId');
            const cocapId = interaction.fields.getTextInputValue('cocapId');
            const stime = interaction.fields.getTextInputValue('stime');
            const departureTime = interaction.fields.getTextInputValue('departureTime');

            proDb.add("nnny", 1);

            const targetChannelId = '1259927864879616264';
            const targetChannel = client.channels.cache.get(targetChannelId);

            if (!targetChannel || !(targetChannel instanceof TextChannel)) {
              throw new Error('لم أتمكن من العثور على القناة المحددة.');
            }

            const imageUrl = 'https://cdn.discordapp.com/attachments/1249608943806709850/1256261012034949162/20240618_215233.png?ex=66801fbd&is=667ece3d&hm=8ceebc76051bf6dabdb0b40aa3cdc9169c378ecbc4c676cbaaaf7dfb66aa06d0&';

            const row = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setLabel('Support | الـدعم الـفنـي .')
                .setStyle('Link')
                .setEmoji('<a:e10:1225909999788757077>')
                .setURL('https://discord.com/channels/714341255336820794/1249609315505930342'),
              new ButtonBuilder()
                .setLabel('The Laws | لـوائح الخـادم .')
                .setStyle('Link')
                .setEmoji('<:BrenShop:1225217938034790450>')
                .setURL('https://discord.com/channels/714341255336820794/1249609145196220525')
            );

            const embed = new EmbedBuilder()
              .setDescription(`**
              — - (  ${proDb.get("nnny")} ) .
              **<:Pilot:1251487347351097397> — قـائـد الـطـائـرة : ${capId}
              ** <:TL_SGEL:1251487394725757048> — ايـدي الـقـائـد : ${capId} 
              <:emoji_256:1253403083631755415> — مـسـاعـد الـقـائـد : ${cocapId} 
              <:emoji_254:1253402858326462474> — مـوعـد الأرسـال : ${stime}
              <:emoji_254:1253402858326462474> — مـوعـد الاقلاع : ${departureTime}**  — الواجهات المتوقعـة : 
              **<:AHeart24:1242453864624689172>  : $${proDb.get("nnny")} .**`)
              .setColor(0x4B0082)
              .setImage(imageUrl);

            await targetChannel.send({ embeds: [embed], components: [row] });
            await interaction.editReply({ content: 'تم إرسال المعلومات بنجاح!', ephemeral: true });
          } catch (error) {
            console.error('خطأ:', error);
            await interaction.editReply({ content: 'حدث خطأ أثناء إرسال المعلومات.', ephemeral: true });
          }
        }
      });

    } catch (error) {
      console.error('خطأ:', error);
      message.reply({ content: 'حدث خطأ غير متوقع.' });
    }
  }
};
