// @ts-nocheck
const { Client, Message, EmbedBuilder } = require('discord.js');
const BaseCommand = require('../../utils/structures/BaseCommand');
const bank = require("../../models/bank");
const db = require("pro.db")
const { fgRoleID } = require('../../config');
const profile = require('../../models/profile');
const points = require('../../models/points');

module.exports = class FahesCommand extends BaseCommand {
  constructor() {
    super('فحص', 'eco', []);
  }

  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {String[]} args 
   */
  async run(client, message, args) {
    if (!message.member.roles.cache.has(fgRoleID) && message.author.id != "1265144461600755753") return;

    if (!message.mentions.members.first()) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription(`**__<:A69:1257157369545228311> – عـزيـزي الإداري .
<:pp186:1257157977337761833> - يـرجـى الـتـأكـد مـن مـنـشـن الـعـضـو الـذي تـرغـب فـي فـحـصـة .
( وشـكـرآ لـك )__**`)
            .setColor("DarkRed")
            .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        ]
      });
    }

    let m = message.mentions.members.first();
    let data = await bank.findOne({ user: m.id });

    if (!data) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription(`**__<:A69:1257157369545228311> – عـزيـزي الإداري .
<:pp186:1257157977337761833> - الـحـسـاب الـمـصـرفـي غـيـر مـفـعـل يـرجـى الـتـوجـة الـى الـدعـم الـفـنـي لـفـتـح حـسـاب الـمـصـرفـي  .
( وشـكـرآ لـك )__**`)
            .setColor("DarkRed")
            .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        ]
      });
    }

    data.amount -= 250;
    await data.save();

    const emoji = client.emojis.cache.get('1249027064342773793');
    if (emoji) {
      message.react(emoji.id);
    } else {
      console.error('Emoji not found!');
    }

    message.channel.send({
      embeds: [
        new EmbedBuilder()
          .setDescription(`**__تم فحص العضو ${m}__**`)
          .setColor("Green")
          .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      ]
    });

    m.send({
      embeds: [
        new EmbedBuilder()
          .setDescription(`**__<:emoji_130:1257168936605061202> - مـصـرف الـراجـحـي .
<:pp721:1257157453028786307> - عـزيـزي الـعـضـو .
<:emoji_117:1253703889014886411> – تـم خـصـم ( 250 ) رسـوم ركـوب الـطـائـرة فـي مـطـار وولـف كـيـنـق مـع تـمـنـيـاتـنـا لـك بـرحـلـة ممـتـعـة   .
<:emoji_130:1257393104315482192> - وزارة المـالـيـة .__**`)
          .setColor("Gold")
          .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      ]
    }).catch(e => console.log(e));

    let d = await profile.findOne({ user: m.id });
    if (!d) {
      d = new profile({ user: m.id, HalaJenea: "لايوجد", Sawabek: "لايوجد", jailTimes: "0", job: "عاطل عن العمل", fhess: 0 });
    }
    d.fhess += 1;
    await d.save();
  }
}
