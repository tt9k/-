const mongoose = require('mongoose');

const identitySchema = new mongoose.Schema({
  serverId: {
    type: String,
    required: true,
  },
  userId: {
    type: String,
    required: true,
  },
  identity: {
    type: Number,
    required: true,
  }
});

module.exports = mongoose.model('identity1', identitySchema);
