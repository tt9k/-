const mongoose = require('mongoose');

const recordSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  criminalRecords: String,
  numInPrison: String,
  criminalStatus: String,
  job: String
});

const Record = mongoose.model('Record', recordSchema);

module.exports = Record;
