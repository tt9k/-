const mongoose = require('mongoose');

const hoeSchema = new mongoose.Schema({
  memberId: {
    type: String,
    required: true,
    unique: true,
  },
  department: {
    type: String,
    required: true,
  },
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  sex: {
    type: String,
    required: true,
  },
  dob: {
    type: String,
    required: true,
  },
  nationality: {
    type: String,
    required: true,
  },
  birth: {
    type: String,
    required: true,
  },
  number: {
    type: String,
    required: true,
  },
  profilePictureUrl: {
    type: String,
    required: true,
  }
});

module.exports = mongoose.model('Hoe', hoeSchema);
